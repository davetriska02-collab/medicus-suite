# Non-routine prescription allocation canvas — learnings

Sibling of the lab allocation canvas (`docs/learnings-lab-allocate.md`) and
the workflow canvas (`docs/learnings-workflow-allocate.md`). Do not
fork-edit either overlay into a dual-mode monster.

## What it is

A stage → confirm → bulk-reassign workbench for **non-routine
prescription-request** task-lists. Same W23 write
(`LabAllocateCore.createClient`). The new files never POST.

## Launch gate

Accept:

- `/{site}/tasks/{slug}/task-list` (also `/tasks/data/{slug}/task-list`)
- `prescription_request_task_non_routine` **and** `prescription_request_task_routine`
  (hyphen twins too)

The live routine inbox (Witley 2026-08-31) is
`?statuses[]=pending-review&viewContext=homepage&masterAssignee=<inbox uuid>`.
That UUID **is** the routine box **only when it is that box**, not the
signed-in staff stamp. Keep it on the GET when it wins. Rows from that
GET are the pile to allocate even when `assignedTo` is a person name
(they sit with the box, not a working-today GP). Stamp them
`rxInboxPile` / Unassigned so they appear in the unallocated list.
Bare GET of the slug returns already-allocated GP work as well.

**Dave 2026-09-15 — non-routine empty while the grid is full.** The
dedicated non-routine page often still has leftover
`viewContext=homepage&masterAssignee=<data-ch-staff>` (or another
queue’s UUID). That is the Privacy Officer #413 class: a working staff
stamp returns `[]` or a personal slice while Medicus’s table shows the
shared pile. #414 marked Rx PASS because the canvas reads
`location.search` — that is exactly the stale filter. Walk
`rxListQueryPlan`: skip the assignee when it equals the staff stamp,
then drop assignee / homepage, then `pending-review` / `pending`, then
bare GET (Signing’s open list). First non-empty wins; a thrown step is
skipped so `loadBoard` cannot wipe `_rows` after a 4xx homepage GET.
Stamp / merge with the **winning** search only. A failed
`masterAssignee` must not restamp the bare pile — person-shaped inbox
names then look like sitting GP work and Split / Top up / Distribute
equally / usual-GP send all report empty. If the winning GET has no
inbox UUID, the grid’s own `ch-task-list-data` ids are a classify-only
hint (already-fetched rows only; never write targets). Honest copy
must say “no doctors working today” vs “no requests in the pile” vs
“the table has rows and Suite’s list is empty”.

Reject:

- EPS / cancellation slugs (W21)
- investigation/result slugs (lab canvas)
- document / workflow slugs (workflow canvas)

W8 (send-to-routine) is the overview DOM macro. This canvas is the
task-list bulk-reassign. They do not share a page.

## Placement / grouping

- `homeColumnKey` stays assignment-only. Named GP is **never** auto-placement.
  Opening the canvas does not move a tile onto a usual GP (H-068).
- Pool groups by requester if present, else registered GP.
- **Send N to usual GP** (`planSendToUsualGp`) is a user-initiated
  stage of **unallocated** rows only. It uses `namedGp` / `namedGpId`,
  never `requester`. Unique staff UUID preferred; colliding names and
  team-inbox labels stay in the pile; not-in usual GPs stay unless that
  action’s checkbox is ticked (session state, not a storage key). Do
  not call lab `planSendToRequester` from this canvas. The control is
  another distribute path, not a featured CTA: preview is supporting
  copy (no accent panel); the button sits in the split-row cluster at
  the same weight as **Distribute equally** (`ms-rxac-action`, not
  `ms-lac-primary`).
- Even-split among doctors working today **ignores named GP** and does
  not rebalance already-sitting work. Only the unallocated Non-Routine
  Prescription Requests pile (Unassigned / that inbox name). Requests
  already sitting with a GP stay on that field and are not in the split
  counts. The bare task-list GET returns the whole open list of that
  type — do not even-split the ones that already have a person assignee.
  After a usual-GP send, Split equally / Top up still apply to whatever
  is left in Unallocated.

## Even split

- Destinations = people with a session on the **working day's appointment book**
  (chip: Working today / Working 8 Sep). Overnight group hours wrap past
  midnight. Practice-profile merge is a union by group `id` (incoming wins
  on the same id only when newer). Split equally binds `planEvenSplit`;
  Top up binds `planTopUp`.
- Cancelled sessions skipped; Medicus/rota absences drop out.
- Nurses / pharmacists / HCAs are excluded when any GP-looking session
  exists; otherwise fall back to everyone working that day (so untitled locums
  still get work).
- Not applied on open. Unallocated is the large pane; doctors sit in
  a sidebar. User clicks **Split equally** to propose (`planEvenSplit`).
  When dests already have sitting work, **Top up empty boxes**
  (`planTopUp`) is the leftover control. When the pile
  is empty, Unallocated greens out and doctors lay out as a grid.
- **Share this box** on a doctor folder even-splits _that folder
  only_ among people working that day (`planEvenSplit` `anyTile`). It is
  not the unallocated pile. Holiday/AWAY leftover is the point.
  Destinations skip the source and anyone away. Nothing in the box,
  or nobody on the book, disables the control rather than hiding it
  when they still have tiles.
- After Split equally the proposal line names the even-split numbers
  ("47 prescriptions would sit with 12 people: 11 with 4, 1 with 3")
  then: drag a patient from one person onto another. Review is a docked card in the panel, not a
  scrim over the folders. The prominent control is **Review then
  write N…**; confirm is **Write to Medicus**.
- **Top up empty boxes** (`planTopUp`) gives remaining unallocated
  work to dests with the fewest current tiles, so a trickle later in
  the day does not land on the first dests. **Distribute equally**
  (`planLevel`) re-deals sitting + unallocated so totals
  differ by at most one. Away boxes are left unless Share this box.
  Both name the destinations (`To: Dr A, Dr B, and Duty GP`). Hover
  `title`s explain each control. Medicus teams from
  `harvestTeamDirectory` can be added (`addTeamColumn`) and join
  the dest list. The unallocated count is the visible pile;
  `markInboxRows` must not restamp a row whose `assignedId` is
  already a person UUID.
- Drag a request onto another doctor to move it. The split / top-up /
  level controls live outside the unallocated pool (that column is a
  drop target). Click always re-renders with a visible note — a
  failed split must not look like a dead button.

## Write path (same class of bugs as the lab canvas)

Write clicked, Medicus did not move the tasks. Four stacked no-ops:

1. `ensureLauncher` (1.5s) was overwriting `_route.search` with the page
   query. Pre-write re-GET then looked empty → vanished abort, no POST.
   Pin `_route` while the overlay is open. Re-GET via
   `fetchRxMergedTaskList` (inbox GET + bare GET, same merge as
   loadBoard). Inbox-only re-GET makes Distribute equally look like
   vanished tasks — sitting GP work is not on the masterAssignee
   filter. Do not `fetchTaskList(slug, pageSearch)` alone.
2. POST 404 on `/tasks/{slug}/task-list/bulk-reassign` never tried the
   hyphen/underscore twin. `bulkReassignPaths` is slug, twin, then the
   captured literal `/tasks/task-list/bulk-reassign`.
3. Even-split dests were names without a staff UUID. Empty Working-today
   fields have no sitting `assignedId`, so name-match against an empty
   directory failed. Pin `columnStaffIds` from the appointment book
   (or a unique directory match) and pass that into `resolveStaffForColumn`.
4. After Write, `loadBoard()` restaged the even split, so the canvas
   looked unchanged even when Medicus had moved them. Pass
   `{ skipSplit: true }`. `draftSummary` already drops `to === from`;
   even-split must only stage `homeColumnKey === POOL` rows.

After Write the canvas shows Medicus, it does not re-split.

Sequential dest POSTs must not abort the rest of the even-split when
one dest fails — that is “only a couple moved each click”. Continue
the remaining dests; retry 400/409/429/5xx once with a fresh list
token. Task-list GET uses `cache: 'no-store'` so reload is not the
pre-write pile. Reassign does not complete the task, so the open-list
total can stay the same while unallocated drops.

## Copy that must not ship

- No Done / Sent / Filed / Allocated / Submitted / Booked / Issued / Signed
- Confirm: "changes who the task sits with — it does not issue, sign, or
  file the prescription"
- Pool title is "Non-routine prescriptions", never "Investigation reports"

## CSS

`#ms-rxac-overlay` / `#ms-rxac-launch` share `lab-allocate-canvas.css`.
Layout classes stay `.ms-lac-*`. The launcher is on `<html>`, so its
focus ring is a literal hex, not `var(--accent)`. After-split dest cards
in `.ms-rxac-board-clear .ms-rxac-folders` size to content (no
`max-height: 100%`); folder-head does not shrink. Review-open adds
`ms-rxac-reviewing` and hides the board.
