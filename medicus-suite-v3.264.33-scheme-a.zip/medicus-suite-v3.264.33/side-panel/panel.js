// Medicus Suite — Side Panel Controller

'use strict';

import { createModuleLoader } from './module-loader.js';
import {
  DEFAULT_SUB_THRESHOLDS,
  ragLevel,
  windowTaskList,
  ledgerSeriesForDay,
} from './modules/submissions/submissions-core.js';
import { recordTaskLists } from './modules/submissions/submissions-ledger.js';
import { initTour, maybeAutoStartTour } from './tour/tour.js';
import { initPalette } from './palette/palette.js';
import { initQuickLeaflet } from './quick-leaflet/quick-leaflet.js';
import { sanitiseHiddenTabs } from './tab-catalog.js';
import { initSetup, setSetupActiveModule } from './setup/setup.js';
import { openRotaTab } from './modules/rota/rota-open.js';
import { openDuplicateCheckerTab } from './duplicate-checker-open.js';
import { OFF_STRIP_IDS, digitJumpCaption, renderTabMenuHTML } from './tab-sections.js';
import { TAB_HELP } from '../shared/tab-help.js';
import { STATUS_RANK } from './modules/sentinel/sentinel-core.js';
import {
  findEntryForPatient,
  maxSeverity as paMaxSeverity,
  sortAlerts as paSortAlerts,
} from './modules/patient-alerts/patient-alerts-core.js';

const content = document.getElementById('suiteContent');
const settingsBtn = document.getElementById('settingsBtn');
let activeModule = 'slots';
let moduleCleanup = null;
let switchSeq = 0;

let panelDisplayPrefs = { theme: 'light', size: 'medium', colorblind: false };
let displayOpen = false;
let _dpCloseHandler = null;

function buildDisplayPopoverHTML() {
  const p = panelDisplayPrefs;
  const themeOpts = [
    ['light', 'Light'],
    ['dark', 'Dark'],
  ]
    .map(
      ([v, l]) =>
        `<button class="dp-seg${p.theme === v ? ' active' : ''}" data-dp-key="theme" data-dp-val="${v}">${l}</button>`
    )
    .join('');
  const sizeOpts = [
    ['small', 'S'],
    ['medium', 'M'],
    ['large', 'L'],
  ]
    .map(
      ([v, l]) =>
        `<button class="dp-seg${p.size === v ? ' active' : ''}" data-dp-key="size" data-dp-val="${v}">${l}</button>`
    )
    .join('');
  return `<div class="dp-popover" id="dpPopover">
    <div class="dp-title">Display</div>
    <div class="dp-row">
      <span class="dp-lbl">Theme</span>
      <div class="dp-segs">${themeOpts}</div>
    </div>
    <div class="dp-row">
      <span class="dp-lbl">Text size</span>
      <div class="dp-segs">${sizeOpts}</div>
    </div>
    <div class="dp-row">
      <span class="dp-lbl">Colour-blind</span>
      <label class="dp-toggle">
        <input type="checkbox" id="dpColorblind" ${p.colorblind ? 'checked' : ''} />
        <span class="dp-track"><span class="dp-thumb"></span></span>
      </label>
    </div>
  </div>`;
}

// Merge the popover's three prefs over the stored object so sibling keys we
// don't manage here (e.g. zen, written by ZenMode) survive a theme/size change.
async function persistDisplayPrefs() {
  const r = await chrome.storage.local.get('suite.display');
  await chrome.storage.local.set({ 'suite.display': { ...(r['suite.display'] || {}), ...panelDisplayPrefs } });
}

function renderDisplayPopover() {
  const host = document.getElementById('displayPopoverHost');
  if (!host) return;
  host.innerHTML = displayOpen ? buildDisplayPopoverHTML() : '';
  if (!displayOpen) return;

  host.querySelectorAll('[data-dp-key]').forEach((btn) => {
    btn.addEventListener('click', () => {
      panelDisplayPrefs[btn.dataset.dpKey] = btn.dataset.dpVal;
      persistDisplayPrefs();
      renderDisplayPopover();
    });
  });
  host.querySelector('#dpColorblind')?.addEventListener('change', (e) => {
    panelDisplayPrefs.colorblind = e.target.checked;
    persistDisplayPrefs();
    renderDisplayPopover();
  });

  // Re-rendering the popover (e.g. on each in-popover click) must not stack
  // duplicate document listeners — remove any previous one before adding.
  if (_dpCloseHandler) document.removeEventListener('click', _dpCloseHandler);
  _dpCloseHandler = (e) => {
    if (!e.target.closest('#displayPopoverHost') && !e.target.closest('#displayBtn')) {
      displayOpen = false;
      document.removeEventListener('click', _dpCloseHandler);
      _dpCloseHandler = null;
      renderDisplayPopover();
    }
  };
  document.addEventListener('click', _dpCloseHandler);
}

// ── Module registry ───────────────────────────────────────────────────────────

const MODULES = {
  slots: { js: () => import('./modules/slots/slots.js'), css: './modules/slots/slots.css' },
  capacity: { js: () => import('./modules/capacity/capacity.js'), css: './modules/capacity/capacity.css' },
  submissions: {
    js: () => import('./modules/submissions/submissions.js'),
    css: './modules/submissions/submissions.css',
  },
  sentinel: { js: () => import('./modules/sentinel/sentinel.js'), css: './modules/sentinel/sentinel.css' },
  activity: { js: () => import('./modules/activity/activity.js'), css: './modules/activity/activity.css' },
  referrals: { js: () => import('./modules/referrals/referrals.js'), css: './modules/referrals/referrals.css' },
  trends: { js: () => import('./modules/trends/trends.js'), css: './modules/trends/trends.css' },
  reception: { js: () => import('./modules/reception/reception.js'), css: './modules/reception/reception.css' },
  signing: { js: () => import('./modules/signing/signing.js'), css: './modules/signing/signing.css' },
  sweep: { js: () => import('./modules/sweep/sweep.js'), css: './modules/sweep/sweep.css' },
  knowledge: { js: () => import('./modules/knowledge/knowledge.js'), css: './modules/knowledge/knowledge.css' },
  leaflets: { js: () => import('./modules/leaflets/leaflets.js'), css: './modules/leaflets/leaflets.css' },
  record: { js: () => import('./modules/record/record.js'), css: './modules/record/record.css' },
  'patient-alerts': {
    js: () => import('./modules/patient-alerts/patient-alerts.js'),
    css: './modules/patient-alerts/patient-alerts.css',
  },
  phrases: { js: () => import('./modules/phrases/phrases.js'), css: './modules/phrases/phrases.css' },
  rota: { js: () => import('./modules/rota/rota.js'), css: './modules/rota/rota.css' },
};
// NOTE: 'rota-app' and 'duplicate-checker' are deliberately absent. They open
// a full page (All tabs → Practice, and the command palette), not a panel
// module. The boot guard (`m in MODULES`) refuses to restore the panel into them.

// ── Help popover (per-tab "what is this?" affordance) ──────────────────────────
// TAB_HELP content lives in shared/tab-help.js — ONE source consumed by both
// this file and pop-out.js (see CLAUDE.md backup-convention-adjacent rule:
// shared content lives in one place, not duplicated per shell).
let helpOpen = false;
let _helpCloseHandler = null;

// Keyboard-shortcuts reference appended to every "?" help popover (see
// wireKeyboardNav below) — one copy, not duplicated per tab. The "g" row's
// title carries the full chord map so it's discoverable on hover without
// cluttering the fixed-width popover with 14 lines.
function buildKeyboardHelpSectionHTML() {
  const chordList = Object.entries(G_CHORD_MAP)
    .map(([key, mod]) => `${key}=${TAB_HELP[mod]?.title || mod}`)
    .join(', ');
  // 1–9 follows the visible strip. Rota manager and Duplicates are not on it,
  // so they are not numbered. The title is the live map (1 Slots, 2 Monitoring, …).
  const jumpCaption =
    digitJumpCaption(
      jumpableTabs().map((t) => t.querySelector('span:not(.nav-badge)')?.textContent?.trim() || t.dataset.module)
    ) || 'Strip order';
  return `<div class="help-popover-row">
    <span class="help-popover-lbl">Keyboard shortcuts</span>
    <div class="help-popover-kbd-list">
      <span><kbd class="help-popover-kbd">ctrl</kbd>+<kbd class="help-popover-kbd">k</kbd> command palette</span>
      <span><kbd class="help-popover-kbd">ctrl</kbd>+<kbd class="help-popover-kbd">alt</kbd>+<kbd class="help-popover-kbd">←/→</kbd> cycle tabs</span>
      <span title="${escStrip(jumpCaption)}"><kbd class="help-popover-kbd">1</kbd>–<kbd class="help-popover-kbd">9</kbd> jump along the strip</span>
      <span title="${escStrip(chordList)}"><kbd class="help-popover-kbd">g</kbd> then a letter — jump to tab</span>
      <span><kbd class="help-popover-kbd">/</kbd> focus search</span>
      <span><kbd class="help-popover-kbd">?</kbd> this help</span>
      <span><kbd class="help-popover-kbd">esc</kbd> close popovers</span>
    </div>
  </div>`;
}

function buildHelpPopoverHTML() {
  const h = TAB_HELP[activeModule];
  const kbdSection = buildKeyboardHelpSectionHTML();
  if (!h) {
    return `<div class="help-popover" id="helpPopover" role="dialog" aria-label="Tab help">
      <div class="help-popover-title">Help</div>
      <div class="help-popover-row"><span class="help-popover-text">No help is available for this tab yet.</span></div>
      ${kbdSection}
    </div>`;
  }
  return `<div class="help-popover" id="helpPopover" role="dialog" aria-label="Help: ${escStrip(h.title)}">
    <div class="help-popover-title">${escStrip(h.title)}</div>
    <div class="help-popover-row">
      <span class="help-popover-lbl">What this is</span>
      <span class="help-popover-text">${escStrip(h.what)}</span>
    </div>
    <div class="help-popover-row">
      <span class="help-popover-lbl">Do this first</span>
      <span class="help-popover-text">${escStrip(h.firstStep)}</span>
    </div>
    ${kbdSection}
  </div>`;
}

function renderHelpPopover() {
  const host = document.getElementById('helpPopoverHost');
  const btn = document.getElementById('helpBtn');
  if (!host) return;
  host.innerHTML = helpOpen ? buildHelpPopoverHTML() : '';
  btn?.setAttribute('aria-expanded', String(helpOpen));
  btn?.classList.toggle('active', helpOpen);
  if (!helpOpen) return;

  if (_helpCloseHandler) document.removeEventListener('click', _helpCloseHandler);
  _helpCloseHandler = (e) => {
    if (!e.target.closest('#helpPopoverHost') && !e.target.closest('#helpBtn')) {
      helpOpen = false;
      document.removeEventListener('click', _helpCloseHandler);
      _helpCloseHandler = null;
      renderHelpPopover();
    }
  };
  document.addEventListener('click', _helpCloseHandler);
}

function wireHelpButton() {
  const btn = document.getElementById('helpBtn');
  if (!btn) return;
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    helpOpen = !helpOpen;
    renderHelpPopover();
  });
  // Esc closes the popover and returns focus to the trigger (keyboard reachable).
  document.addEventListener('keydown', (e) => {
    if ((e.key === 'Escape' || e.key === 'Esc') && helpOpen) {
      helpOpen = false;
      if (_helpCloseHandler) {
        document.removeEventListener('click', _helpCloseHandler);
        _helpCloseHandler = null;
      }
      renderHelpPopover();
      btn.focus();
    }
  });
}

// ── "All tabs" menu ───────────────────────────────────────────────────────────
// At the 360-420px panel width the tab strip can only show the active tab; the
// rest scroll off (appraisal G1). This menu lists every visible tab by its full
// name so any tab is reachable in one click without horizontal scrolling. Built
// live from the nav DOM on each open, so it reflects current visibility/order.

let allTabsOpen = false;
let _allTabsCloseHandler = null;
let _hiddenTabIds = new Set();

function navTabMenuEntry(tab) {
  const mod = tab.dataset.module || '';
  return {
    id: mod,
    icon: tab.querySelector('svg')?.outerHTML || '',
    label: tab.querySelector('span:not(.nav-badge)')?.textContent?.trim() || tab.getAttribute('aria-label') || mod,
    active: tab.classList.contains('active'),
    hidden: tab.classList.contains('nav-tab-hidden') || _hiddenTabIds.has(mod),
  };
}

function offStripMenuEntries() {
  const root = document.getElementById('offStripLaunchers')?.content;
  if (!root) return [];
  return [...root.querySelectorAll('[data-module]')].map((el) => {
    const mod = el.dataset.module || '';
    return {
      id: mod,
      icon: el.querySelector('svg')?.outerHTML || '',
      label: el.querySelector('span')?.textContent?.trim() || el.getAttribute('aria-label') || mod,
      active: false,
      hidden: _hiddenTabIds.has(mod),
    };
  });
}

function buildAllTabsPopoverHTML() {
  const entries = [...document.querySelectorAll('.nav-tab')].map(navTabMenuEntry).concat(offStripMenuEntries());
  const rows = renderTabMenuHTML(entries, escStrip);
  return `<div class="alltabs-popover" id="allTabsPopover" role="menu" aria-label="All tabs">
    <div class="alltabs-title">Jump to a tab</div>
    <div class="alltabs-list">${rows}</div>
    <div class="alltabs-hint">Ctrl+Alt+← / → switches tabs</div>
  </div>`;
}

function activateAllTabsItem(mod) {
  const tab = document.querySelector(`.nav-tab[data-module="${mod}"]`);
  if (tab) {
    tab.click();
    return;
  }
  if (mod === 'rota-app') openRotaTab();
  else if (mod === 'duplicate-checker') openDuplicateCheckerTab();
}

function renderAllTabsPopover() {
  const host = document.getElementById('allTabsPopoverHost');
  const btn = document.getElementById('allTabsBtn');
  if (!host) return;
  host.innerHTML = allTabsOpen ? buildAllTabsPopoverHTML() : '';
  btn?.setAttribute('aria-expanded', String(allTabsOpen));
  btn?.classList.toggle('active', allTabsOpen);
  if (!allTabsOpen) return;

  // A strip row clicks that tab. Rota manager and Duplicates open their full page.
  host.querySelectorAll('.alltabs-item').forEach((item) => {
    item.addEventListener('click', () => {
      const mod = item.dataset.module;
      allTabsOpen = false;
      if (_allTabsCloseHandler) {
        document.removeEventListener('click', _allTabsCloseHandler);
        _allTabsCloseHandler = null;
      }
      renderAllTabsPopover();
      activateAllTabsItem(mod);
    });
  });

  if (_allTabsCloseHandler) document.removeEventListener('click', _allTabsCloseHandler);
  _allTabsCloseHandler = (e) => {
    if (!e.target.closest('#allTabsPopoverHost') && !e.target.closest('#allTabsBtn')) {
      allTabsOpen = false;
      document.removeEventListener('click', _allTabsCloseHandler);
      _allTabsCloseHandler = null;
      renderAllTabsPopover();
    }
  };
  document.addEventListener('click', _allTabsCloseHandler);
}

function wireAllTabsButton() {
  const btn = document.getElementById('allTabsBtn');
  if (!btn) return;
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    allTabsOpen = !allTabsOpen;
    renderAllTabsPopover();
  });
  document.addEventListener('keydown', (e) => {
    if ((e.key === 'Escape' || e.key === 'Esc') && allTabsOpen) {
      allTabsOpen = false;
      if (_allTabsCloseHandler) {
        document.removeEventListener('click', _allTabsCloseHandler);
        _allTabsCloseHandler = null;
      }
      renderAllTabsPopover();
      btn.focus();
    }
  });
}

// Shared typing-guard predicate — single source used by wireTabNavShortcuts
// below AND by wireKeyboardNav's single-key bindings, so the two never drift
// out of step on what counts as "the user is typing".
function isTypingTarget(el) {
  if (!el) return false;
  const tag = el.tagName;
  return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || !!el.isContentEditable;
}

// Visible, jumpable nav tabs in current DOM order — shared by the Ctrl/Cmd+Alt
// cycler below and by wireKeyboardNav's digit-jump / "g" chord (item 6.1/6.2):
// hidden tabs (suite.hiddenTabs) and off-strip launchers (rota manager,
// duplicates) are excluded from all three. 1–9 is this list, so demoting those
// two does not renumber Slots … Signing.
function jumpableTabs() {
  const skip = new Set(OFF_STRIP_IDS);
  return Array.from(document.querySelectorAll('.nav-tab')).filter(
    (t) => !t.classList.contains('nav-tab-hidden') && !skip.has(t.dataset.module)
  );
}

// Keyboard tab navigation (power-user finding R4): Ctrl/Cmd+Alt+Left/Right cycle
// the visible in-panel tabs without the mouse. Skipped while typing in a field,
// and skips Rota manager and Duplicates (both open a full browser tab, not an
// in-panel switch — the compact 'rota' module stays in the cycle).
function wireTabNavShortcuts() {
  document.addEventListener(
    'keydown',
    (e) => {
      if (!(e.ctrlKey || e.metaKey) || !e.altKey || e.shiftKey) return;
      if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
      if (isTypingTarget(document.activeElement)) return;
      const tabs = jumpableTabs();
      if (!tabs.length) return;
      e.preventDefault();
      const activeIdx = tabs.findIndex((t) => t.classList.contains('active'));
      const dir = e.key === 'ArrowRight' ? 1 : -1;
      const start = activeIdx === -1 ? 0 : activeIdx;
      const next = (start + dir + tabs.length) % tabs.length;
      tabs[next].click();
    },
    true
  );
}

// ── Keyboard-first panel navigation (power-user partner ask: jump tabs, focus
// search, no mouse trips) ────────────────────────────────────────────────────
// A single global keydown layer, thin and additive — it never claims a key
// already owned elsewhere: Ctrl/Cmd+K (command palette, palette.js), Ctrl/Cmd+
// Alt+←/→ (tab cycling, wireTabNavShortcuts above) or Esc (popover dismissal,
// wireHelpButton/wireAllTabsButton). What it adds:
//   1. Digits 1-9        → jump to the Nth visible tab (jumpableTabs()).
//   2. "g" then a letter  → chord-jump to a specific tab (G_CHORD_MAP).
//   3. "/"                → focus the active module's search/filter input.
//   4. "?" (shift+/)      → open the per-tab help popover (now carrying a
//                           keyboard-shortcuts section, see buildHelpPopoverHTML).
// Reduced-attention rule (item 6): none of this fires while typing in a field,
// or while any shell-level overlay (command palette, tour, tab chooser, or this
// panel's own help/all-tabs/display popovers) is open — see isOverlayOpen().

// Second key of a "g" chord → module to jump to. Preference is the module's
// own data-module first letter; where two or more modules share a first
// letter, one keeps it and the rest are reassigned a letter from elsewhere in
// their name so every entry stays mnemonic. Collisions and their resolutions:
//   s* → slots keeps 's'; sentinel → 'm' (Monitoring), submissions → 'u',
//        sweep → 'w'
//   c* → capacity keeps 'c'
//   r* → referrals keeps 'r'; record → 'd', reception → 'e'
//   trends → 'n' (t is unused after Today tab removal)
const G_CHORD_MAP = {
  s: 'slots',
  m: 'sentinel',
  r: 'referrals',
  c: 'capacity',
  a: 'activity',
  u: 'submissions',
  k: 'knowledge',
  l: 'leaflets',
  w: 'sweep',
  e: 'reception',
  d: 'record',
  n: 'trends',
};

const G_CHORD_TIMEOUT_MS = 1500;
let _gChordArmed = false;
let _gChordTimer = null;
let _gChordIndicatorEl = null;

// Transient "g …" indicator — the chord has no other visible cue, so this is
// the discoverability affordance the panel ask calls for. Styled to emulate
// the existing kbd-token + floating-popover patterns (suite-palette-kbd,
// help-popover) rather than inventing a new visual language.
function showGChordIndicator() {
  if (!_gChordIndicatorEl) {
    _gChordIndicatorEl = document.createElement('div');
    _gChordIndicatorEl.className = 'kbdnav-chord-indicator';
    _gChordIndicatorEl.setAttribute('aria-live', 'polite');
    _gChordIndicatorEl.innerHTML = '<kbd>g</kbd> …';
    document.body.appendChild(_gChordIndicatorEl);
  }
  _gChordIndicatorEl.classList.add('kbdnav-chord-indicator-visible');
}

function hideGChordIndicator() {
  _gChordIndicatorEl?.classList.remove('kbdnav-chord-indicator-visible');
}

function armGChord() {
  _gChordArmed = true;
  showGChordIndicator();
  if (_gChordTimer) clearTimeout(_gChordTimer);
  _gChordTimer = setTimeout(disarmGChord, G_CHORD_TIMEOUT_MS);
}

function disarmGChord() {
  _gChordArmed = false;
  if (_gChordTimer) {
    clearTimeout(_gChordTimer);
    _gChordTimer = null;
  }
  hideGChordIndicator();
}

// Any open shell-level overlay — a keyboard shortcut must never steal focus
// out from under one of these (reduced-attention rule, item 6). The command
// palette, tour and tab chooser render into the DOM rather than exposing an
// importable "is open" flag, so they're checked by their layer class; the
// panel's own help/all-tabs/display popovers are already tracked in local
// module state (helpOpen/allTabsOpen/displayOpen) declared above.
function isOverlayOpen() {
  return (
    helpOpen ||
    allTabsOpen ||
    displayOpen ||
    !!document.querySelector('.suite-palette-layer') ||
    !!document.querySelector('.suite-tour-layer') ||
    !!document.querySelector('.suite-tabs-layer')
  );
}

// "/" target: the active module's own search/filter input, checked in
// priority order (search-typed input, then anything explicitly marked
// data-search, then the first visible plain text input). No-op silently if
// the active module has none of these.
function isVisible(el) {
  const r = el.getBoundingClientRect();
  return r.width > 0 && r.height > 0;
}

function focusModuleSearch() {
  if (!content) return;
  const tiers = ['input[type="search"]', '[data-search]', 'input[type="text"], input:not([type])'];
  for (const sel of tiers) {
    const target = Array.from(content.querySelectorAll(sel)).find(isVisible);
    if (target) {
      target.focus();
      if (typeof target.select === 'function') target.select();
      return;
    }
  }
}

function wireKeyboardNav() {
  document.addEventListener(
    'keydown',
    (e) => {
      if (isOverlayOpen()) return;
      if (isTypingTarget(document.activeElement)) return;
      if (e.ctrlKey || e.metaKey || e.altKey) return; // these are single-key/chord bindings only
      // A bare modifier keydown (e.g. Shift held down before typing "?") must not
      // itself count as the chord's second key or cancel an armed chord.
      if (e.key === 'Shift' || e.key === 'Control' || e.key === 'Alt' || e.key === 'Meta' || e.key === 'CapsLock') {
        return;
      }

      // Mid-chord: this keystroke completes or cancels the "g" chord — either
      // way it's consumed here, so it never also falls through to the "?"/
      // "/"/digit handlers below.
      if (_gChordArmed) {
        disarmGChord();
        const mod = e.key.length === 1 ? G_CHORD_MAP[e.key.toLowerCase()] : undefined;
        const tab = mod && jumpableTabs().find((t) => t.dataset.module === mod);
        if (tab) {
          e.preventDefault();
          tab.click();
        }
        return;
      }

      if (e.key.toLowerCase() === 'g') {
        e.preventDefault();
        armGChord();
        return;
      }

      if (e.key === '?') {
        e.preventDefault();
        if (!helpOpen) {
          helpOpen = true;
          renderHelpPopover();
        }
        return;
      }

      if (e.key === '/') {
        e.preventDefault();
        focusModuleSearch();
        return;
      }

      if (e.key >= '1' && e.key <= '9') {
        const tabs = jumpableTabs();
        const idx = Number(e.key) - 1;
        if (idx < tabs.length) {
          e.preventDefault();
          tabs[idx].click();
        }
      }
    },
    true
  );
}

// ── Nav overflow detection ────────────────────────────────────────────────────

const navEl = document.querySelector('.suite-nav');
const navTabsEl = document.querySelector('.nav-tabs');
const navIndicatorRight = document.querySelector('.nav-scroll-right');
const navIndicatorLeft = document.querySelector('.nav-scroll-left');

function updateNavOverflow() {
  if (!navTabsEl) return;
  const sl = navTabsEl.scrollLeft;
  const hasRight =
    navTabsEl.scrollWidth > navTabsEl.clientWidth + 4 && sl + navTabsEl.clientWidth < navTabsEl.scrollWidth - 4;
  const hasLeft = sl > 4;
  navEl.classList.toggle('has-overflow-right', hasRight);
  navEl.classList.toggle('has-overflow-left', hasLeft);
}

navTabsEl?.addEventListener('scroll', updateNavOverflow);
if (navTabsEl) new ResizeObserver(updateNavOverflow).observe(navTabsEl);
updateNavOverflow();

// Persistent discoverability: at 400px only a couple of tabs are visible at a
// time, so newcomers miss that the rest exist. The command palette reaches
// every tab (including ones scrolled off the rail or hidden via "choose your
// tabs"), so advertise the full count on its button permanently.
(function initPaletteHint() {
  const btn = document.getElementById('paletteBtn');
  if (!btn) return;
  const offStrip = document.getElementById('offStripLaunchers')?.content?.querySelectorAll('[data-module]').length || 0;
  const total = document.querySelectorAll('.nav-tab').length + offStrip;
  if (!total) return;
  btn.title = `Jump to any of the ${total} tabs · Command palette (Ctrl+K)`;
  // The bare count badge ("15") read as a mystery number to the appraisal panel;
  // name it for assistive tech and tooltip so it can't be mistaken for an unread
  // count. (Practice appraisal U2, 2026-06-21.)
  btn.setAttribute('aria-label', `Command palette — jump to any of the ${total} tabs (Ctrl+K)`);
  let badge = btn.querySelector('.palette-count');
  if (!badge) {
    badge = document.createElement('span');
    badge.className = 'palette-count';
    badge.setAttribute('aria-hidden', 'true');
    btn.appendChild(badge);
  }
  badge.textContent = String(total);
})();

[navIndicatorRight, navIndicatorLeft].forEach((el) => {
  if (!el) return;
  el.style.setProperty('pointer-events', 'auto');
  el.style.setProperty('cursor', 'pointer');
});
navIndicatorRight?.addEventListener('click', () => navTabsEl?.scrollBy({ left: 120, behavior: 'smooth' }));
navIndicatorLeft?.addEventListener('click', () => navTabsEl?.scrollBy({ left: -120, behavior: 'smooth' }));

// ── Slots nav badge ───────────────────────────────────────────────────────────
document.addEventListener('suite:slots:count', (e) => {
  const tab = document.querySelector('[data-module="slots"]');
  if (!tab) return;
  let badge = tab.querySelector('.nav-badge');
  if (!badge) {
    badge = document.createElement('span');
    badge.className = 'nav-badge';
    tab.appendChild(badge);
  }
  const n = e.detail.count;
  badge.textContent = n != null ? String(n) : '';
  badge.style.display = n != null && n >= 0 ? '' : 'none';
});

// CSS dedup set for module stylesheets — passed to createModuleLoader
const loadedCss = new Set();

// ── Navigation ────────────────────────────────────────────────────────────────

document.querySelectorAll('.nav-tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    // A drag that ends on the same tab still fires a click; suppress it so a
    // reorder doesn't also switch module.
    if (tab.dataset.dragged === '1') {
      delete tab.dataset.dragged;
      return;
    }
    const mod = tab.dataset.module;
    if (mod === 'duplicate-checker') {
      openDuplicateCheckerTab();
      return;
    }
    if (mod === 'rota-app') {
      openRotaTab();
      return;
    }
    if (mod === activeModule) return;
    switchModule(mod);
  });
});

// ── Drag-and-drop tab reordering ──────────────────────────────────────────────
// Persists a global preferred order in suite.tabOrder (see side-panel/tab-order.js).
// Panel and pop-out share the key and each reconciles against its own tab set.

(async () => {
  const { reconcileTabOrder, STORAGE_KEY } = await import('./tab-order.js');
  if (!navTabsEl) return;

  const tabIds = () => [...navTabsEl.querySelectorAll('.nav-tab')].map((t) => t.dataset.module);

  // Apply a stored order by reordering existing nodes (listeners survive).
  function applyOrder(stored) {
    const order = reconcileTabOrder(tabIds(), stored);
    order.forEach((id) => {
      const el = navTabsEl.querySelector(`.nav-tab[data-module="${id}"]`);
      if (el) navTabsEl.appendChild(el);
    });
    updateNavOverflow();
  }

  // Initial apply from storage.
  const r = await chrome.storage.local.get(STORAGE_KEY);
  applyOrder(r[STORAGE_KEY]);

  // Live sync: re-apply when another context changes the order.
  chrome.storage.onChanged.addListener((changes) => {
    if (changes[STORAGE_KEY]) applyOrder(changes[STORAGE_KEY].newValue);
  });

  let dragSrc = null;

  navTabsEl.querySelectorAll('.nav-tab').forEach(makeDraggable);

  function makeDraggable(tab) {
    tab.setAttribute('draggable', 'true');
    tab.title = tab.title || 'Drag to reorder';

    tab.addEventListener('dragstart', (e) => {
      dragSrc = tab;
      tab.classList.add('nav-tab-dragging');
      e.dataTransfer.effectAllowed = 'move';
      // Some browsers require data to be set for the drag to start.
      try {
        e.dataTransfer.setData('text/plain', tab.dataset.module);
      } catch (_) {}
    });

    tab.addEventListener('dragend', () => {
      tab.classList.add('nav-tab-just-dragged');
      // Mark so the synthesised click after a drag is swallowed, then clear.
      tab.dataset.dragged = '1';
      setTimeout(() => {
        delete tab.dataset.dragged;
      }, 0);
      tab.classList.remove('nav-tab-dragging', 'nav-tab-just-dragged');
      navTabsEl
        .querySelectorAll('.nav-tab-drop-before, .nav-tab-drop-after')
        .forEach((t) => t.classList.remove('nav-tab-drop-before', 'nav-tab-drop-after'));
      dragSrc = null;
    });

    tab.addEventListener('dragover', (e) => {
      if (!dragSrc || dragSrc === tab) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      const rect = tab.getBoundingClientRect();
      const after = e.clientX > rect.left + rect.width / 2;
      navTabsEl
        .querySelectorAll('.nav-tab-drop-before, .nav-tab-drop-after')
        .forEach((t) => t.classList.remove('nav-tab-drop-before', 'nav-tab-drop-after'));
      tab.classList.add(after ? 'nav-tab-drop-after' : 'nav-tab-drop-before');
    });

    tab.addEventListener('drop', (e) => {
      e.preventDefault();
      if (!dragSrc || dragSrc === tab) return;
      const rect = tab.getBoundingClientRect();
      const after = e.clientX > rect.left + rect.width / 2;
      navTabsEl.insertBefore(dragSrc, after ? tab.nextSibling : tab);
      chrome.storage.local.set({ [STORAGE_KEY]: tabIds() });
      updateNavOverflow();
    });
  }
})();

settingsBtn.addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

// ── Popout button ─────────────────────────────────────────────────────────────

const popoutBtn = document.getElementById('popoutBtn');

async function updatePopoutBtn() {
  if (!popoutBtn || !window.PopoutManager) return;
  const isOpen = await window.PopoutManager.isOpen();
  popoutBtn.title = isOpen ? 'Focus floating window' : 'Pop out to floating window';
  popoutBtn.classList.toggle('active', isOpen);
}

popoutBtn?.addEventListener('click', async () => {
  if (!window.PopoutManager) return;
  await window.PopoutManager.open();
  await updatePopoutBtn();
});

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!sender || sender.id !== chrome.runtime.id) return;
  if (msg?.type === 'popout:closed') updatePopoutBtn();
});

updatePopoutBtn();

const switchModule = createModuleLoader({
  modules: MODULES,
  container: content,
  loadedCss,
  getSwitchSeq: () => switchSeq,
  incSwitchSeq: () => ++switchSeq,
  getCleanup: () => moduleCleanup,
  setCleanup: (fn) => {
    moduleCleanup = fn;
  },
  setActive: (name) => {
    activeModule = name;
    setSetupActiveModule(name);
    // Keep an open help popover in step with the tab the user just switched to.
    if (helpOpen) renderHelpPopover();
  },
  onPersist: (name) => {
    chrome.storage.local.set({ 'panel.activeModule': name });
  },
  escFn: escStrip,
});

// ── Service worker messages ────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender) => {
  // F5: Only accept messages from this extension's own contexts.
  if (!sender || sender.id !== chrome.runtime.id) return;
  // Dispatched UNCONDITIONALLY (v3.173.2): the Capacity tab listens for this
  // same DOM event as its ONLY live-update path, so the old
  // `activeModule === 'slots'` gate silently froze Capacity (the classic
  // symptom: "slots no longer auto refresh"). Unconditional dispatch cannot
  // double-fire — module switching runs the outgoing module's cleanup(), which
  // removes its listener, so at any instant only the active module listens.
  if (msg?.type === 'slots:refresh') {
    document.dispatchEvent(new CustomEvent('suite:slots:refresh'));
  }
  if (msg?.type === 'ms-open-panel' && (msg.module === 'sentinel' || msg.module === 'slots')) {
    switchModule(msg.module);
  }
});

// ── Alert roll-up (groups elevated demand strips into one summary bar) ────────
// Three strips (#wrStrip, #rmStrip, #subRagStrip) each render independently below
// the nav. When two or more are in an ELEVATED (amber/red) state they stack and
// compete for the same scarce vertical space, so a single severity-ordered roll-up
// bar replaces the stack: one line at max severity with a pill per elevated channel,
// expandable (chevron) to the full strips for detail. Each strip's own poller is
// untouched — it still renders its own DOM; it just reports its resulting level here
// via reportAlert(), and the roll-up reads that shared bus. Red auto-expands.
//
// CLINICAL SAFETY: grouping only collapses the *presentation* of strips that are
// already showing; nothing is hidden that wasn't on screen, and the roll-up itself
// carries the max severity. Green/calm states are never "elevated", so the roll-up
// only ever appears when there is genuinely more than one elevated signal.
const alertRollupEl = document.getElementById('alertRollup');
const alertStackEl = document.getElementById('alertStack');
const alertBus = { waiting: null, triage: null, demand: null };
let _rollupExpanded = null; // null = use default (red→open, amber→closed); else session choice

// Persistent "keep the roll-up expanded" preference (suite.rollup.alwaysExpanded).
// Power users want the amber detail pinned on screen instead of clicking Details
// every time the alert set changes; when on, the roll-up renders expanded always.
// Toggled from the command palette; cached here, kept current via onChanged.
let _rollupAlwaysExpanded = false;
chrome.storage.local.get('suite.rollup.alwaysExpanded').then((r) => {
  _rollupAlwaysExpanded = r['suite.rollup.alwaysExpanded'] === true;
  renderRollup();
});
chrome.storage.onChanged.addListener((changes) => {
  if ('suite.rollup.alwaysExpanded' in changes) {
    _rollupAlwaysExpanded = changes['suite.rollup.alwaysExpanded'].newValue === true;
    _rollupExpanded = null; // re-derive against the new preference
    renderRollup();
  }
});

const ALERT_CHANNELS = ['waiting', 'triage', 'demand'];

function reportAlert(channel, state) {
  // state = { level, label, count, meta?, title? } or null when inactive.
  alertBus[channel] = state;
  renderRollup();
}

function renderRollup() {
  if (!alertRollupEl || !alertStackEl) return;
  const elevated = ALERT_CHANNELS.map((k) => alertBus[k]).filter(
    (a) => a && (a.level === 'amber' || a.level === 'red')
  );

  if (elevated.length < 2) {
    // Nothing to group — restore the normal stacked strips, roll-up hidden.
    alertRollupEl.className = 'alert-rollup alert-rollup-hidden';
    alertRollupEl.innerHTML = '';
    alertStackEl.style.display = '';
    _rollupExpanded = null;
    return;
  }

  const hasRed = elevated.some((a) => a.level === 'red');
  const maxLevel = hasRed ? 'red' : 'amber';
  // Expanded when: the user pinned it open, OR (default) it's red. Amber starts
  // collapsed unless the session toggle or the persistent pref says otherwise.
  // The pinned pref supplies the DEFAULT only — a session click must still be
  // able to collapse (audit low: the Hide button visibly no-op'd while
  // suite.rollup.alwaysExpanded was on, because this re-forced true on the
  // re-render the click itself triggered).
  if (_rollupExpanded === null) _rollupExpanded = _rollupAlwaysExpanded || hasRed;

  const pills = elevated
    .map(
      (a) =>
        `<span class="pill pill--${a.level}"${a.title ? ` title="${escStrip(a.title)}"` : ''}><span class="pill-dot"></span><span class="pill-name">${escStrip(
          a.label
        )}</span>${a.count != null ? `<span class="pill-count">${a.count}</span>` : ''}${
          a.meta ? `<span class="pill-meta">${escStrip(a.meta)}</span>` : ''
        }</span>`
    )
    .join('');

  // R6: severity is carried by a WORD, not only colour — red reads "URGENT",
  // amber "ALERTS" (uppercased by CSS), so escalation survives colourblind mode.
  const word = maxLevel === 'red' ? 'urgent' : 'alerts';
  // Timestamp the bar so every figure is anchored to a moment the manager can
  // quote ("as at 11:02") — a live number with no time is one she won't cite.
  const stamp = _fmtHHMM(Date.now());
  alertRollupEl.className = `alert-rollup alert-rollup--${maxLevel}`;
  alertRollupEl.setAttribute('aria-expanded', String(_rollupExpanded));
  alertRollupEl.innerHTML = `
    <span class="alert-rollup-icon">${maxLevel === 'red' ? '🔴' : '⚠'}</span>
    <span class="alert-rollup-count">${elevated.length} ${word}</span>
    <span class="alert-rollup-pills">${pills}</span>
    <span class="alert-rollup-stamp" title="Figures as at ${stamp}">${stamp}</span>
    <button class="alert-rollup-toggle" title="${
      _rollupExpanded ? 'Collapse the detail — the alert stays' : 'Show the detail'
    }">${_rollupExpanded ? 'Hide' : 'Details'}<span class="alert-rollup-chev">${
      _rollupExpanded ? '▾' : '▸'
    }</span></button>
  `;
  alertStackEl.style.display = _rollupExpanded ? '' : 'none';
}

// Toggle expand/collapse on click anywhere in the roll-up bar.
alertRollupEl?.addEventListener('click', () => {
  _rollupExpanded = !_rollupExpanded;
  renderRollup();
});

// ── Waiting Room strip (global — visible on every module) ─────────────────────

let SITE_ID_WR = null;
const WR_POLL_MS = 30 * 1000;
const wrStripEl = document.getElementById('wrStrip');
let _wrPrevHtml = null; // changed-guard for the 30s poll re-render (see below)

// Waiting-room alert thresholds (minutes). User-configurable via the alert-threshold
// editor (suite.waitingRoom.thresholds); defaults match the long-standing fixed
// values. Cached to avoid a storage read per poll; kept current via onChanged.
const DEFAULT_WR_THRESHOLDS = { amber: 10, red: 20 };
let _wrThresholds = { ...DEFAULT_WR_THRESHOLDS };

function _sanitiseWrThresholds(raw) {
  const d = DEFAULT_WR_THRESHOLDS;
  if (!raw || typeof raw !== 'object') return { ...d };
  const amber = Number.isFinite(raw.amber) && raw.amber > 0 ? Math.round(raw.amber) : d.amber;
  const red = Number.isFinite(raw.red) && raw.red > 0 ? Math.round(raw.red) : d.red;
  // Red must be at least amber to be meaningful; an inverted pair falls back to defaults.
  return red >= amber ? { amber, red } : { ...d };
}

chrome.storage.local.get('suite.waitingRoom.thresholds').then((r) => {
  _wrThresholds = _sanitiseWrThresholds(r['suite.waitingRoom.thresholds']);
});
chrome.storage.onChanged.addListener((changes) => {
  if ('suite.waitingRoom.thresholds' in changes) {
    _wrThresholds = _sanitiseWrThresholds(changes['suite.waitingRoom.thresholds'].newValue);
    fetchAndRenderStrip(true);
  }
});

let wrPoller = null;

async function fetchAndRenderStrip(bypassCache = false) {
  if (document.visibilityState !== 'visible') return true;
  try {
    // Shared memoised fetcher (audit M10): coalesces this strip's poll with the
    // Sentinel module's waiting-room fetches of the same endpoint.
    // Practice code is re-resolved inside on every call, so user changes still
    // take effect immediately.
    const { raw, code } = await window.AppointmentsFeed.fetchRaw({ module: 'panel-wr-strip', bypassCache });
    SITE_ID_WR = code;
    if (!code) {
      // No practice code set — hide strip silently. User will see the prompt in Options.
      if (wrStripEl) {
        wrStripEl.className = 'wr-strip wr-strip-hidden';
        wrStripEl.innerHTML = '';
      }
      return true;
    }
    const arrived = window.AppointmentsFeed.arrivedEntries(raw)
      .map((e) => ({
        name: e.patient?.name ?? 'Unknown',
        start: e.start ?? '',
        startDateTime: e.startDateTime ?? null,
        minutesWaiting: calcStripWait(e.startDateTime),
      }))
      .sort((a, b) => (a.start < b.start ? -1 : 1));

    renderStrip(arrived);
    updateStripBadge(arrived.length);
    return true;
  } catch (_) {
    // Network error or no Medicus session — keep strip hidden, don't spam console
    return false;
  }
}

function calcStripWait(dt) {
  if (!dt) return null;
  const ms = new Date(dt).getTime();
  if (isNaN(ms)) return null;
  const m = Math.round((Date.now() - ms) / 60000);
  return m > 0 ? m : 0;
}

function renderStrip(patients) {
  if (!wrStripEl) return;
  if (patients.length === 0) {
    wrStripEl.className = 'wr-strip wr-strip-hidden';
    wrStripEl.innerHTML = '';
    reportAlert('waiting', null);
    _wrPrevHtml = null;
    // Strip just lost its "Monitoring →" button — the badge falls back to the
    // nav tab (see applySentinelBadgeToDom).
    applySentinelBadgeToDom(_sentBadgeActionCount, _sentBadgeHasRed);
    return;
  }

  const maxWait = Math.max(...patients.map((p) => p.minutesWaiting ?? 0));
  const T = _wrThresholds;
  const urgency = maxWait >= T.red ? 'red' : maxWait >= T.amber ? 'amber' : 'green';

  // Build name chips — show up to 3, then "+N more"
  const shown = patients.slice(0, 3);
  const extra = patients.length - shown.length;
  const chips = shown
    .map((p) => {
      const mins = p.minutesWaiting;
      const cls =
        mins != null && mins >= T.red
          ? 'wr-chip-red'
          : mins != null && mins >= T.amber
            ? 'wr-chip-amber'
            : 'wr-chip-ok';
      const wait = mins != null ? ` · ${mins}m` : '';
      return `<span class="wr-chip ${cls}">${escStrip(p.name)}${wait}</span>`;
    })
    .join('');
  const extraChip = extra > 0 ? `<span class="wr-chip wr-chip-more">+${extra} more</span>` : '';

  wrStripEl.className = `wr-strip wr-strip-${urgency}`;
  // Changed-guard (audit, 2026-07-18): the strip used to rebuild identical
  // innerHTML on every successful 30s poll, destroying hover/tooltip state
  // mid-use. Same signature pattern as the pa-strip.
  const wrHtml = `
    <span class="wr-strip-icon">🚶</span>
    <span class="wr-strip-count">${patients.length} waiting</span>
    <span class="wr-strip-chips">${chips}${extraChip}</span>
    <button class="wr-strip-goto" title="Go to Monitoring">Monitoring →</button>
  `;
  if (wrHtml === _wrPrevHtml && wrStripEl.firstElementChild) {
    return; // unchanged — the previous reportAlert payload also still holds
  }
  _wrPrevHtml = wrHtml;
  wrStripEl.innerHTML = wrHtml;

  wrStripEl.querySelector('.wr-strip-goto')?.addEventListener('click', () => {
    switchModule('sentinel');
    document.querySelector('[data-module="sentinel"]')?.scrollIntoView({ behavior: 'smooth', inline: 'nearest' });
  });
  // Rebuilt the button above — reapply the last-known Monitoring badge state.
  applySentinelBadgeToDom(_sentBadgeActionCount, _sentBadgeHasRed);

  reportAlert('waiting', {
    level: urgency,
    label: 'Waiting',
    count: patients.length,
    // F4: surface the worst single wait on the collapsed pill so proximity-to-breach
    // isn't hidden behind DETAILS (a 12m and a 55m wait must not look identical).
    meta: maxWait > 0 ? maxWait + 'm' : null,
    // R1 + threshold context: plain-language hover, naming the wait that tripped
    // the level (amber ≥10 min, red ≥20 min) so the count carries its own line.
    title:
      `Waiting room: ${patients.length} patient${patients.length === 1 ? '' : 's'} arrived` +
      (maxWait > 0 ? `, longest waiting ${maxWait} min` : '') +
      (urgency === 'red' ? ` (red ≥${T.red} min)` : urgency === 'amber' ? ` (amber ≥${T.amber} min)` : ''),
  });
}

// ── Badge-enabled cache ───────────────────────────────────────────────────────
// Cached to avoid a storage round-trip on every WR poll. Seeded on load,
// kept current via onChanged. Default true (safe: badge shows if pref unknown).
let _badgeEnabled = true;
chrome.storage.local.get('suite.notifications').then((r) => {
  const prefs = r['suite.notifications'] || {};
  _badgeEnabled = prefs.badgeEnabled !== false;
});
chrome.storage.onChanged.addListener((changes) => {
  if (changes['suite.notifications']) {
    const prefs = changes['suite.notifications'].newValue || {};
    _badgeEnabled = prefs.badgeEnabled !== false;
    // Clear a stale count immediately on disable rather than waiting for the
    // next waiting-room poll (≤30s) to notice.
    if (!_badgeEnabled) chrome.action.setBadgeText({ text: '' });
  }
});

function updateStripBadge(count) {
  // Respect suite.notifications.badgeEnabled — if disabled, always clear the badge.
  if (!_badgeEnabled || count <= 0) {
    chrome.action.setBadgeText({ text: '' });
  } else {
    chrome.action.setBadgeText({ text: String(count) });
    chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });
  }
}

// ── Alert log helper ──────────────────────────────────────────────────────────
// Prepend entry to suite.alertLog (capped at 50). Never stores patient names —
// counts/labels only. Safe to call from any panel context.
async function appendAlertLog(entry) {
  try {
    const r = await chrome.storage.local.get('suite.alertLog');
    const log = Array.isArray(r['suite.alertLog']) ? r['suite.alertLog'] : [];
    log.unshift(entry);
    if (log.length > 50) log.length = 50;
    await chrome.storage.local.set({ 'suite.alertLog': log });
  } catch (_) {}
}

// ── Quiet pill ────────────────────────────────────────────────────────────────
// Shows an amber pill in the nav when clinic (quiet) mode is active.
// Polls every 30s and reacts to storage changes. Click clears quiet mode.

const _quietPillEl = document.getElementById('quietPill');

function _fmtHHMM(epochMs) {
  const d = new Date(epochMs);
  const h = String(d.getHours()).padStart(2, '0');
  const m = String(d.getMinutes()).padStart(2, '0');
  return `${h}:${m}`;
}

async function _updateQuietPill() {
  if (!_quietPillEl) return;
  try {
    const r = await chrome.storage.local.get('suite.quietUntil');
    const until = r['suite.quietUntil'];
    const isActive = until && typeof until === 'number' && until > Date.now();
    if (isActive) {
      const hhmm = _fmtHHMM(until);
      _quietPillEl.textContent = `🔕 ${hhmm}`;
      _quietPillEl.title = `Clinic mode — desktop pop-ups and sounds muted until ${hhmm}. Click to switch off.`;
      _quietPillEl.classList.remove('quiet-pill-hidden');
    } else {
      _quietPillEl.classList.add('quiet-pill-hidden');
      _quietPillEl.title = '';
    }
  } catch (_) {}
}

_quietPillEl?.addEventListener('click', () => {
  window.QuietMode?.clear();
});

// Poll every 30s for expiry
setInterval(_updateQuietPill, 30 * 1000);

// React immediately to storage changes
chrome.storage.onChanged.addListener((changes) => {
  if ('suite.quietUntil' in changes) _updateQuietPill();
});

// Initial render
_updateQuietPill();

function escStrip(s) {
  // Quote-safe (audit M8, 2026-07-18): escStrip feeds double-quoted attribute
  // contexts (pa-strip pill title carries staff-typed free text) — without
  // quote escaping a '"' broke out of the attribute.
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ── Failure-backoff poller ────────────────────────────────────────────────────
// makePoller(fn, baseMs, label) → { start(overrideMs?), stop() }
//
// Runs fn() on a self-scheduling setTimeout chain.  fn() should return true
// (or any truthy value) on success and false on a network/API failure.
// Consecutive failures double the interval (capped at 8× base); a single
// success resets to base.  console.warn fires once per new escalation level.
//
// start(overrideMs) can be called while a tick is in progress (e.g. the RM
// strip restarts itself on config change) — a _scheduledByStart flag prevents
// the in-progress tick from stacking a second setTimeout on top.

function makePoller(fn, baseMs, label) {
  let _timer = null;
  let _failCount = 0;
  let _currentBaseMs = baseMs;
  let _startedDuring = false; // set if start() called while tick is running

  function _schedule(delayMs) {
    if (_timer) clearTimeout(_timer);
    _timer = setTimeout(_tick, delayMs);
  }

  async function _tick() {
    _timer = null;
    _startedDuring = false;
    const ok = await fn();
    if (_startedDuring) return; // start() rescheduled us already — don't double-schedule
    if (ok === false) {
      _failCount++;
      const level = Math.min(_failCount, 3); // 2^3 = 8 → cap at 8×
      const delay = _currentBaseMs * Math.pow(2, level);
      console.warn(`[${label}] poll failure #${_failCount}, backing off to ${delay}ms`);
      _schedule(delay);
    } else {
      _failCount = 0;
      _schedule(_currentBaseMs);
    }
  }

  return {
    start(overrideMs) {
      _startedDuring = true; // suppress any in-progress tick's post-schedule
      if (overrideMs != null) _currentBaseMs = overrideMs;
      _failCount = 0;
      _schedule(0); // fire first tick immediately
      return this;
    },
    stop() {
      _startedDuring = true;
      if (_timer) {
        clearTimeout(_timer);
        _timer = null;
      }
    },
  };
}

// Listen for Pusher-triggered refresh from service worker
// F5: Sender guard — only accept messages from intra-extension contexts.
// Light coalescing: fetchAndRenderStrip / fetchAndRenderRmStrip are already
// guarded by document.visibilityState and their own fetch-in-flight guard
// (_rmFetchInFlight for the RM strip), so duplicate refreshes within the same
// tick are absorbed naturally by awaiting the existing in-flight call.
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!sender || sender.id !== chrome.runtime.id) return;
  if (msg?.type === 'waiting:refresh') fetchAndRenderStrip(true);
  if (msg?.type === 'requestMonitor:refresh') fetchAndRenderRmStrip();
});

// Boot the strip — initial fetch + self-scheduling poll with failure backoff
wrPoller = makePoller(fetchAndRenderStrip, WR_POLL_MS, 'wr-strip').start();

// ── Monitoring (Sentinel) action-count badge — visible from any tab ───────────
// Panel finding: the GP wants to know whether the patient open in Medicus has
// red/amber monitoring chips without switching to the Monitoring tab. The rules
// engine runs ONLY in the content script (content-scripts/sentinel.js); this
// reads its already-published snapshot via getSentinelSnapshot — it never runs
// the rules engine itself. Refreshed on chrome.tabs.onActivated and on the
// content script's bare 'sentinel:snapshot-updated' ping (debounced — the ping
// can fire repeatedly on SPA churn).
//
// CLINICAL SAFETY: an unavailable snapshot, chips: null, or no active Medicus
// tab must render as NO badge — never "0" and never an implied all-clear. The
// badge only ever signals "action-needed chips are present"; absence of the
// badge means "unknown", not "clear".
let _sentBadgeTimer = null;

function scheduleSentinelBadgeUpdate() {
  if (_sentBadgeTimer) return;
  _sentBadgeTimer = setTimeout(() => {
    _sentBadgeTimer = null;
    updateSentinelBadge();
  }, 400);
}

async function updateSentinelBadge() {
  let chips = null; // stays null (= unavailable) unless a real snapshot with chips comes back
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (tab?.id && tab?.url && /medicus\.health/.test(tab.url)) {
      const snapshot = await chrome.tabs.sendMessage(tab.id, { action: 'getSentinelSnapshot' });
      if (snapshot && !snapshot.unavailable && Array.isArray(snapshot.chips)) {
        chips = snapshot.chips;
      }
    }
  } catch (_) {
    // No Medicus tab, no content script mounted, or the message failed — chips
    // stays null, which renders as no badge (see CLINICAL SAFETY note above).
  }
  const actionCount = chips ? chips.filter((c) => STATUS_RANK[c.status] <= 2).length : null;
  const hasRed = chips ? chips.some((c) => STATUS_RANK[c.status] === 0) : false;
  applySentinelBadgeToDom(actionCount, hasRed);
}

// Last-known state, reapplied whenever the WR strip re-renders (it owns the
// "Monitoring →" button this badge decorates) so the two stay in sync without
// a second round-trip to the content script.
let _sentBadgeActionCount = null;
let _sentBadgeHasRed = false;

function applySentinelBadgeToDom(actionCount, hasRed) {
  _sentBadgeActionCount = actionCount;
  _sentBadgeHasRed = hasRed;

  const gotoBtn = wrStripEl?.querySelector('.wr-strip-goto');
  // Prefer the strip chip when the WR strip is actually showing a "Monitoring →"
  // button; fall back to the nav-tab badge when the strip is hidden (no
  // waiting patients) — same fallback pattern as the Slots nav badge above.
  if (gotoBtn) {
    let chip = gotoBtn.querySelector('.wr-strip-goto-count');
    if (actionCount) {
      if (!chip) {
        chip = document.createElement('span');
        chip.className = 'wr-strip-goto-count';
        gotoBtn.appendChild(chip);
      }
      chip.textContent = `· ${actionCount}`;
      chip.classList.toggle('wr-strip-goto-count-red', hasRed);
      chip.classList.toggle('wr-strip-goto-count-amber', !hasRed);
    } else if (chip) {
      chip.remove();
    }
  }

  const navTab = document.querySelector('[data-module="sentinel"]');
  if (!navTab) return;
  let badge = navTab.querySelector('.nav-badge');
  if (actionCount && !gotoBtn) {
    if (!badge) {
      badge = document.createElement('span');
      badge.className = 'nav-badge';
      navTab.appendChild(badge);
    }
    badge.textContent = String(actionCount);
    badge.classList.toggle('nav-badge-red', hasRed);
    badge.classList.toggle('nav-badge-amber', !hasRed);
    badge.style.display = '';
  } else if (badge) {
    badge.style.display = 'none';
  }
}

chrome.tabs.onActivated.addListener(() => scheduleSentinelBadgeUpdate());
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!sender || sender.id !== chrome.runtime.id) return;
  if (msg?.type === 'sentinel:snapshot-updated') scheduleSentinelBadgeUpdate();
});
updateSentinelBadge();

// ── Request Monitor strip (v1.3) ─────────────────────────────────────────────
// Sits below the waiting room strip. Hidden entirely unless toggled on in
// Options AND a team UUID is configured. Pills show counts for the four
// buckets; clicking a pill opens the filtered task list in a new tab.

const rmStripEl = document.getElementById('rmStrip');
let rmPoller = null;
let rmPollSeconds = 300;

let _rmFetchInFlight = null;

async function fetchAndRenderRmStrip() {
  if (_rmFetchInFlight) return _rmFetchInFlight;
  _rmFetchInFlight = _doFetchAndRenderRmStrip().finally(() => {
    _rmFetchInFlight = null;
  });
  return _rmFetchInFlight;
}

async function _doFetchAndRenderRmStrip() {
  if (document.visibilityState !== 'visible') return true;
  if (!rmStripEl || !window.RequestMonitor) return true;

  const cfg = await window.RequestMonitor.getConfig();
  if (!cfg.enabled || !cfg.assigneeId) {
    rmStripEl.className = 'rm-strip rm-strip-hidden';
    rmStripEl.innerHTML = '';
    reportAlert('triage', null);
    return true;
  }
  // Adjust poll interval if config changed — restart the poller at the new interval
  if (cfg.pollSeconds && cfg.pollSeconds * 1000 !== rmPollSeconds * 1000) {
    rmPollSeconds = cfg.pollSeconds;
    if (rmPoller) rmPoller.start(rmPollSeconds * 1000);
  }

  const { code } = await window.PracticeCode.resolve();
  if (!code) {
    rmStripEl.className = 'rm-strip';
    rmStripEl.innerHTML = `<span class="rm-strip-icon">⚠</span><span class="rm-strip-label">Triage:</span><span class="rm-strip-error">No practice code</span>`;
    reportAlert('triage', null);
    return true;
  }

  // SINGLE-POLLER (audit H10): the service worker alarm owns pollAll and writes
  // suite.requestMonitor.state. The strip reads that cache only — never a second
  // panel-side fetch of the four triage task lists.
  let result = null;
  try {
    const stR = await chrome.storage.local.get('suite.requestMonitor.state');
    const st = stR['suite.requestMonitor.state'];
    if (st && st.buckets) {
      result = { buckets: st.buckets, error: st.error || null };
    }
  } catch (_) {
    /* fall through */
  }
  if (!result) {
    result = { buckets: {}, error: 'Waiting for background poll…' };
  }

  renderRmStrip(result, code, cfg.assigneeId);
  applyTriageAlerts(result.buckets);
  return true;
}

function renderRmStrip(result, practiceCode, assigneeId) {
  if (!rmStripEl) return;
  const buckets = window.RequestMonitor.BUCKETS;
  const pills = buckets
    .map((b) => {
      const data = result.buckets?.[b.key];
      const count = data?.count ?? 0;
      const isReply = b.status === 'reply-received';
      const cls = ['rm-pill', isReply ? 'rm-pill-reply' : 'rm-pill-new', count > 0 ? 'rm-pill-active' : '']
        .filter(Boolean)
        .join(' ');
      const clickUrl = window.RequestMonitor.buildClickUrl(practiceCode, b.taskType, b.status, assigneeId);
      return `<span class="${cls}" data-rm-url="${escStrip(clickUrl)}" title="${escStrip(b.label)}">
      <span class="rm-pill-label">${escStrip(b.label)}</span>
      <span class="rm-pill-count">${count}</span>
    </span>`;
    })
    .join('');

  const errorBlock = result.error ? `<span class="rm-strip-error">${escStrip(result.error)}</span>` : '';

  rmStripEl.className = 'rm-strip';
  rmStripEl.innerHTML = `
    <span class="rm-strip-icon">📋</span>
    <span class="rm-strip-label">Triage:</span>
    ${pills}
    ${errorBlock}
  `;

  // Wire click handlers
  rmStripEl.querySelectorAll('.rm-pill[data-rm-url]').forEach((el) => {
    el.addEventListener('click', () => {
      const url = el.dataset.rmUrl;
      if (url) chrome.tabs.create({ url });
    });
  });
}

// ── Triage capacity alerts ────────────────────────────────────────────────────

const _triageAlertedBuckets = new Map(); // key → last alerted count (session memory)

async function applyTriageAlerts(buckets) {
  if (!rmStripEl || !window.TriageAlertEngine || !window.TriageAlertIO) return;
  const rules = await window.TriageAlertIO.getRules();
  const { triggered, maxLevel } = window.TriageAlertEngine.evaluate(buckets, rules);

  // Update strip class
  rmStripEl.classList.remove('rm-strip-alerted-amber', 'rm-strip-alerted-red');
  if (maxLevel) rmStripEl.classList.add(`rm-strip-alerted-${maxLevel}`);

  // Feed the alert roll-up: triage counts as elevated only when a threshold is
  // crossed (calm pill counts aren't an alert). Count = buckets over threshold.
  // F1: report the total flagged TASK count (sum across over-threshold buckets),
  // not the bucket count — so the collapsed pill reconciles with the expanded strip.
  const triageTasks = triggered.reduce((sum, t) => sum + (t.count || 0), 0);
  reportAlert(
    'triage',
    maxLevel
      ? {
          level: maxLevel,
          label: 'Triage',
          count: triageTasks,
          // R1: plain-language hover.
          title: `Triage: ${triageTasks} task${triageTasks === 1 ? '' : 's'} over the alert threshold`,
        }
      : null
  );

  // Desktop notifications — once per threshold crossing per session
  const quietNow = (await window.QuietMode?.isQuiet?.()) ?? false;
  for (const t of triggered) {
    const prev = _triageAlertedBuckets.get(t.key);
    const crossed = prev === undefined || (prev < t.threshold && t.count >= t.threshold);
    if (crossed) {
      _triageAlertedBuckets.set(t.key, t.count);
      // Always append to alert log (even when quiet) — counts/labels only, no patient names.
      appendAlertLog({
        ts: Date.now(),
        channel: 'triage',
        level: t.level || 'amber',
        label: t.label + ': ' + t.count + ' tasks',
      });
      // Skip desktop notification if clinic mode (quiet) is active.
      if (!quietNow && Notification.permission === 'granted') {
        new Notification('Medicus Suite — Triage alert', {
          body: `${t.label}: ${t.count} tasks (threshold ${t.threshold})`,
          silent: true,
        });
      }
    } else {
      _triageAlertedBuckets.set(t.key, t.count);
    }
  }
  // Clear alerted state for buckets that dropped back below threshold
  for (const [key, _] of _triageAlertedBuckets) {
    if (!triggered.find((t) => t.key === key)) _triageAlertedBuckets.delete(key);
  }
}

// React to config changes — re-render immediately.
// CONFIG keys only, never the prefix: pollAll writes suite.requestMonitor.state
// on every cycle, so a startsWith() match re-triggers the poll it came from —
// an infinite self-sustaining poll loop hammering the API (same hazard the
// service worker guards with its own RM_CONFIG_KEYS allowlist).
const RM_STRIP_CONFIG_KEYS = [
  'suite.requestMonitor.enabled',
  'suite.requestMonitor.assigneeId',
  'suite.requestMonitor.pollSeconds',
  'suite.requestMonitor.notifyEnabled',
  'suite.requestMonitor.notifySound',
];
chrome.storage.onChanged.addListener((changes) => {
  if (RM_STRIP_CONFIG_KEYS.some((k) => k in changes)) {
    fetchAndRenderRmStrip();
  }
  if (Object.keys(changes).some((k) => k.startsWith('suite.triageAlert.'))) {
    fetchAndRenderRmStrip();
  }
  if (changes['submissions.thresholds']) {
    fetchAndRenderSubRagStrip();
  }
});

// Boot the rm strip — initial fetch + self-scheduling poll with failure backoff
// Initial poll interval — will adjust to cfg.pollSeconds on first fetch
rmPoller = makePoller(fetchAndRenderRmStrip, rmPollSeconds * 1000, 'rm-strip').start();

// ── Submissions demand strip (global — visible on every module) ───────────────
// Shows amber/red when medical or admin request counts hit configured thresholds.
// Polls every 60s, but only makes API calls when at least one threshold is enabled.

const subRagStripEl = document.getElementById('subRagStrip');
let _subRagPrevLevel = null;
const SUB_RAG_POLL_MS = 60 * 1000;

const SUB_RAG_TYPES = [
  { key: 'medical', label: 'Medical', apiType: 'medical_patient_request_task' },
  { key: 'admin', label: 'Admin', apiType: 'admin_patient_request_task' },
];

// DEFAULT_SUB_THRESHOLDS + ragLevel are imported from submissions-core.js so the
// strip and the Submissions module share one threshold definition.
function _subRagLevel(key, value, thresholds) {
  return ragLevel(value, { ...DEFAULT_SUB_THRESHOLDS[key], ...(thresholds[key] || {}) });
}

async function fetchAndRenderSubRagStrip() {
  if (document.visibilityState !== 'visible') return true;
  if (!subRagStripEl) return true;

  const stored = await chrome.storage.local.get('submissions.thresholds');
  const thresholds = { ...DEFAULT_SUB_THRESHOLDS, ...(stored['submissions.thresholds'] || {}) };

  const anyEnabled = SUB_RAG_TYPES.some((t) => thresholds[t.key]?.enabled);
  if (!anyEnabled) {
    subRagStripEl.className = 'sub-rag-strip sub-rag-strip-hidden';
    subRagStripEl.innerHTML = '';
    reportAlert('demand', null);
    return true;
  }

  const { code, source } = await window.PracticeCode.resolve();
  if (!code) {
    reportAlert('demand', null);
    return true;
  }

  // LOCAL calendar date, not toISOString() — UTC would query yesterday during
  // the first BST hour of the day (same fix as condor's todayISO, v3.35.2).
  const _now = new Date();
  const today = `${_now.getFullYear()}-${String(_now.getMonth() + 1).padStart(2, '0')}-${String(_now.getDate()).padStart(2, '0')}`;
  const results = await Promise.allSettled(
    SUB_RAG_TYPES.map(async (tt) => {
      const url = `https://${code}.api.england.medicus.health/tasks/data/${tt.apiType}/task-list?createdAt_startDate=${today}&createdAt_endDate=${today}`;
      // Route through ApiDiag so SubRag errors/latency show in the Debug panel,
      // consistent with the WR and Request-Monitor strips.
      const r = await window.ApiDiag.fetch({ module: 'panel-sub-rag-strip', url, code, codeSource: source });
      if (!r.ok) throw new Error(`${tt.label} HTTP ${r.status}`);
      const d = await r.json();
      // windowTaskList: thresholds must fire on tasks CREATED today, even if
      // the server-side createdAt filter is ever renamed/ignored upstream.
      return { key: tt.key, label: tt.label, tasks: windowTaskList(d, today, today).tasks };
    })
  );

  // Thresholds fire on the DAY-LEDGER count (tasks seen today, including ones
  // the team has since completed) — the task-list API only contains open
  // tasks, so a raw count would sag as work is cleared and could un-trip an
  // alert mid-morning while true demand keeps climbing (v3.153.0).
  let ledger = null;
  try {
    const byKey = {};
    for (const res of results) {
      if (res.status === 'fulfilled') byKey[res.value.key] = res.value.tasks;
    }
    ledger = await recordTaskLists(byKey);
  } catch (_) {
    // Storage failure — fall back to live (open-only) counts below.
  }
  const ledgerSeries = ledger
    ? ledgerSeriesForDay(
        ledger,
        today,
        SUB_RAG_TYPES.map((t) => t.key)
      )
    : null;
  for (const res of results) {
    if (res.status !== 'fulfilled') continue;
    res.value.count = ledgerSeries ? ledgerSeries[res.value.key].total : res.value.tasks.length;
  }

  // A failure in any sub-request counts as a polling failure for backoff purposes
  const anyFailed = results.some((r) => r.status === 'rejected');

  const triggered = [];
  let maxLevel = null;
  for (let i = 0; i < SUB_RAG_TYPES.length; i++) {
    const res = results[i];
    if (res.status !== 'fulfilled') continue;
    const { key, label, count } = res.value;
    const level = _subRagLevel(key, count, thresholds);
    if (!level) continue;
    // Capture the threshold this category crossed, so the roll-up tooltip can
    // show the line ("Medical 70 ≥60") — power users / the manager wanted the
    // number to carry the threshold it tripped, not blind trust in a default.
    const crossed = thresholds[key] ? thresholds[key][level] : null;
    triggered.push({ label, count, level, threshold: crossed });
    if (level === 'red' || maxLevel === null) maxLevel = level;
    else if (level === 'amber' && maxLevel !== 'red') maxLevel = level;
  }

  if (triggered.length === 0) {
    subRagStripEl.className = 'sub-rag-strip sub-rag-strip-hidden';
    subRagStripEl.innerHTML = '';
    _subRagPrevLevel = null;
    reportAlert('demand', null);
    return !anyFailed;
  }

  // Log on level transition only (null→level or level change), counts/labels only.
  if (maxLevel !== null && maxLevel !== _subRagPrevLevel) {
    appendAlertLog({
      ts: Date.now(),
      channel: 'sub-rag',
      level: maxLevel,
      label: 'Demand: ' + triggered.map((t) => t.label + ' ' + t.count).join(', '),
    });
  }
  _subRagPrevLevel = maxLevel;

  const pills = triggered
    .map((t) => `<span class="sub-rag-pill sub-rag-pill--${t.level}">${t.label}: ${t.count}</span>`)
    .join('');

  subRagStripEl.className = `sub-rag-strip sub-rag-strip--${maxLevel}`;
  subRagStripEl.innerHTML = `
    <span class="sub-rag-icon">📊</span>
    <span class="sub-rag-label">Demand:</span>
    ${pills}
    <button class="sub-rag-goto" title="Go to Submissions">Submissions →</button>
  `;
  subRagStripEl.querySelector('.sub-rag-goto')?.addEventListener('click', () => switchModule('submissions'));
  // F1: report total demand TASKS (Medical + Admin sum), not the category count,
  // so "Demand N" reconciles with the expanded "Medical X / Admin Y" detail.
  const demandTasks = triggered.reduce((sum, t) => sum + (t.count || 0), 0);
  reportAlert('demand', {
    level: maxLevel,
    label: 'Demand',
    count: demandTasks,
    // R1 + threshold context: plain-language hover with the breakdown AND the line
    // each category crossed (e.g. "Medical 70 ≥60, Admin 45 ≥40").
    title: `Demand: ${demandTasks} new request${demandTasks === 1 ? '' : 's'} awaiting review (${triggered
      .map((t) => `${t.label} ${t.count}${t.threshold != null ? ` ≥${t.threshold}` : ''}`)
      .join(', ')})`,
  });
  return !anyFailed;
}

let subRagPoller = makePoller(fetchAndRenderSubRagStrip, SUB_RAG_POLL_MS, 'sub-rag-strip').start();

// ── Suite health strip (global — visible on every module) ─────────────────────
// Self-diagnosis, not a clinical alert: shown ONLY when >= 1 DOM contract this
// suite depends on (shared/dom-contracts.js) has been probed 'degraded' by the
// runtime canary (shared/contract-canary.js, injected into the live Medicus
// page — see manifest.json's content-script list). The canary does all the
// probing and hysteresis; this strip only reads its result out of
// chrome.storage.local — no API calls, no polling backoff needed. Calm and
// amber-only by design (never red — Medicus changing its own UI is expected,
// not a clinical emergency). Same strip family as #wrStrip/#rmStrip/
// #subRagStrip (CLAUDE.md "Global demand / alert strips"); panel-only by the
// same convention those three already use (no WR/RM/SubRag strips in the
// pop-out either — see pop-out/pop-out.js's MODULES comment).
const healthStripEl = document.getElementById('healthStrip');
const HEALTH_POLL_MS = 30 * 1000;

// Acknowledge/snooze: an amber self-diagnosis the user has SEEN shouldn't nag
// every day while the degradation is unchanged. Dismiss hides the strip for
// this exact degraded-contract set for 7 days; if the set CHANGES (a new
// contract degrades, or one recovers and a different one breaks) the strip
// reappears immediately — new problems always surface. Options → Suite health
// keeps the full detail regardless of the snooze.
const HEALTH_SNOOZE_KEY = 'health.stripSnooze';
const HEALTH_SNOOZE_MS = 7 * 24 * 60 * 60 * 1000;

async function fetchAndRenderHealthStrip() {
  if (!healthStripEl) return true;
  try {
    const r = await chrome.storage.local.get(['health.contracts', HEALTH_SNOOZE_KEY, 'suite.swLoadErrors']);
    const health = r['health.contracts'] || {};
    const swErrors = Array.isArray(r['suite.swLoadErrors']) ? r['suite.swLoadErrors'] : [];
    const DC = window.DomContracts;
    const degradedIds = Object.keys(health)
      .filter((id) => health[id]?.status === 'degraded')
      .sort();
    if ((degradedIds.length === 0 || !DC) && swErrors.length === 0) {
      healthStripEl.className = 'health-strip health-strip-hidden';
      healthStripEl.innerHTML = '';
      return true;
    }
    const swSig = swErrors
      .map((e) => (e && e.script) || '')
      .filter(Boolean)
      .sort()
      .join(',');
    const sig = degradedIds.join('|') + (swErrors.length ? '|sw:' + swSig : '');
    const snooze = r[HEALTH_SNOOZE_KEY];
    if (snooze && snooze.sig === sig && typeof snooze.until === 'number' && Date.now() < snooze.until) {
      healthStripEl.className = 'health-strip health-strip-hidden';
      healthStripEl.innerHTML = '';
      return true;
    }
    // Several contracts can share one owning feature (e.g. the three queue-chip
    // contracts) — de-dupe so the strip reads "Queue chips degraded", not
    // "Queue chips, Queue chips, Queue chips degraded".
    const features =
      DC && degradedIds.length
        ? degradedIds.map((id) => DC.get(id)?.feature || id).filter((f, i, arr) => arr.indexOf(f) === i)
        : [];
    const swText = swErrors.length ? 'Extension module failed to load — some tools may be missing.' : '';
    const degText =
      features.length && DC ? `Medicus may have changed — ${escStrip(features.join(', '))} degraded.` : '';
    const line = [swText, degText].filter(Boolean).join(' ') + ' Details in Options → Suite health.';
    healthStripEl.className = 'health-strip health-strip-amber';
    healthStripEl.innerHTML = `
      <span class="health-strip-icon">⚠</span>
      <span class="health-strip-text">${line}</span>
      <button class="health-strip-goto">Details →</button>
      <button class="health-strip-dismiss" title="Dismiss for 7 days (reappears if anything new degrades)" aria-label="Dismiss health warning for 7 days">✕</button>
    `;
    healthStripEl.querySelector('.health-strip-goto')?.addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('options/options.html#sect-health') });
    });
    healthStripEl.querySelector('.health-strip-dismiss')?.addEventListener('click', async () => {
      await chrome.storage.local.set({ [HEALTH_SNOOZE_KEY]: { sig, until: Date.now() + HEALTH_SNOOZE_MS } });
      fetchAndRenderHealthStrip();
    });
    return true;
  } catch (_) {
    return false;
  }
}

let healthPoller = makePoller(fetchAndRenderHealthStrip, HEALTH_POLL_MS, 'health-strip').start();
// Snappier than the 30s poll: the canary writes this key directly, so react
// to it immediately when the panel is open and watching.
chrome.storage.onChanged.addListener((changes) => {
  if (changes['health.contracts'] || changes['suite.swLoadErrors']) fetchAndRenderHealthStrip();
});

// ── Local bits strip (practice OS-sync — not GitHub, not Practice Profile) ────
const localBitsStripEl = document.getElementById('localBitsStrip');

function renderLocalBitsStrip(state) {
  if (!localBitsStripEl || !window.LocalBits) return;
  if (!window.LocalBits.isReloadAvailable(state)) {
    localBitsStripEl.className = 'local-bits-strip local-bits-strip-hidden';
    localBitsStripEl.innerHTML = '';
    return;
  }
  localBitsStripEl.className = 'local-bits-strip local-bits-strip-ready';
  localBitsStripEl.innerHTML = `
    <span class="local-bits-strip-text">Suite files updated — Reload (v${escStrip(state.diskVersion)} on disk, running v${escStrip(state.runningVersion || '')}).</span>
    <button type="button" class="local-bits-strip-reload">Reload</button>
  `;
  localBitsStripEl.querySelector('.local-bits-strip-reload')?.addEventListener('click', () => {
    try {
      chrome.runtime.reload();
    } catch (_) {}
  });
}

async function fetchAndRenderLocalBitsStrip() {
  if (!localBitsStripEl || !window.LocalBits) return true;
  try {
    const state = await window.LocalBits.checkAndPersist();
    renderLocalBitsStrip(state);
    return true;
  } catch (_) {
    return false;
  }
}

fetchAndRenderLocalBitsStrip();
chrome.storage.onChanged.addListener((changes) => {
  if (Object.keys(changes).some((k) => k.startsWith('suite.localBits.'))) {
    window.LocalBits?.getState()
      .then(renderLocalBitsStrip)
      .catch(() => {});
  }
});

// ── Patient Alerts strip (global — visible on every module) ───────────────────
// Shows the practice's own per-patient flags (patientAlerts.byPatient, owned by
// the Patient Alerts tab) for the patient currently open in Medicus, so the
// flag is seen the moment the record loads whatever tab the panel is on.
// Identity comes from the same Sentinel snapshot bridge the Monitoring badge
// uses; alerts are looked up fresh on every render (wrong-patient safety — a
// navigation must never leave the previous patient's flags on screen).
// Panel-only, same convention as the other strips; deliberately NOT in the
// alert roll-up (ALERT_CHANNELS): those group practice-demand signals, whereas
// this is patient-context — collapsing a safeguarding flag into a demand
// roll-up could hide it at exactly the moment it matters.
//
// CLINICAL SAFETY: absence of this strip means "no flags recorded or patient
// not identified", never a verified "no concerns".
const paStripEl = document.getElementById('paStrip');
// 60s backstop only (audit M12): the strip's real triggers are the snapshot
// ping, tabs.onActivated and the store's onChanged below — the poll exists so
// none of those being missed can strand a stale strip for long.
const PA_STRIP_POLL_MS = 60 * 1000;
let _paStripPrevSig = null;
// patientAlerts.byPatient cached with onChanged invalidation (audit M12) —
// the strip used to re-read the whole store from chrome.storage every tick.
let _paStripStore = null;
chrome.storage.local.get('patientAlerts.byPatient').then((r) => {
  _paStripStore = r['patientAlerts.byPatient'] || {};
});

async function fetchAndRenderPaStrip() {
  if (!paStripEl) return true;
  // Visibility gate (audit M12) — this was the only strip without one; the
  // tabs.query + IPC round-trip ran ~8,600×/day even while hidden.
  if (document.visibilityState !== 'visible') return true;
  const hide = () => {
    paStripEl.className = 'pa-strip pa-strip-hidden';
    paStripEl.innerHTML = '';
    _paStripPrevSig = null;
  };
  try {
    let pc = null;
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    let tab = tabs[0]?.url && /medicus\.health/.test(tabs[0].url) ? tabs[0] : null;
    // Audit M11: with 2+ Medicus tabs the fallback pick is arbitrary — label
    // the strip so a background tab's patient can't be misread as the one on
    // screen.
    let fromBackgroundTab = false;
    if (!tab) {
      const any = await chrome.tabs.query({ url: 'https://*.medicus.health/*' });
      tab = any[0] || null;
      fromBackgroundTab = !!tab && any.length > 1;
    }
    if (tab?.id) {
      try {
        const snap = await chrome.tabs.sendMessage(tab.id, { action: 'getSentinelSnapshot' });
        if (snap && !snap.unavailable && snap.patientContext) pc = snap.patientContext;
      } catch (_) {
        /* content script not mounted */
      }
    }
    if (!pc) {
      hide();
      return true;
    }
    if (_paStripStore === null) {
      const r = await chrome.storage.local.get('patientAlerts.byPatient');
      _paStripStore = r['patientAlerts.byPatient'] || {};
    }
    const found = findEntryForPatient(_paStripStore, pc);
    const alerts = found ? paSortAlerts(found.entry.alerts) : [];
    if (alerts.length === 0) {
      hide();
      return true;
    }
    const level = paMaxSeverity(alerts) === 'red' ? 'red' : 'amber';
    const name = pc.displayName || pc.patientName || pc.name || '';
    const sig = `${found.key}|${alerts.map((a) => `${a.id}:${a.severity}`).join(',')}`;
    if (sig === _paStripPrevSig) return true; // unchanged — don't rebuild (keeps focus/hover stable)
    _paStripPrevSig = sig;
    const pills = alerts
      .slice(0, 4)
      .map(
        (a) =>
          `<span class="pa-strip-pill pa-strip-pill--${a.severity}" title="${escStrip(a.note || a.label)}">${escStrip(a.label)}</span>`
      )
      .join('');
    const more = alerts.length > 4 ? `<span class="pa-strip-more">+${alerts.length - 4} more</span>` : '';
    paStripEl.className = `pa-strip pa-strip--${level}`;
    paStripEl.innerHTML = `
      <span class="pa-strip-icon">&#x2691;</span>
      <span class="pa-strip-label">PATIENT${name ? ` · ${escStrip(name)}` : ''}${fromBackgroundTab ? ' · OTHER TAB' : ''}</span>
      ${pills}${more}
      <button class="pa-strip-goto" title="Open the Patient Alerts tab">Manage &rarr;</button>
    `;
    paStripEl.querySelector('.pa-strip-goto')?.addEventListener('click', () => switchModule('patient-alerts'));
    return true;
  } catch (_) {
    hide();
    return false;
  }
}

let paStripPoller = makePoller(fetchAndRenderPaStrip, PA_STRIP_POLL_MS, 'pa-strip').start();
// React immediately to patient changes (snapshot ping), tab switches, and
// alert edits — the 10s poll is only the backstop.
let _paStripDebounce = null;
function schedulePaStripRefresh() {
  if (_paStripDebounce) return;
  _paStripDebounce = setTimeout(() => {
    _paStripDebounce = null;
    fetchAndRenderPaStrip();
  }, 400);
}
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!sender || sender.id !== chrome.runtime.id) return;
  if (msg?.type === 'sentinel:snapshot-updated') schedulePaStripRefresh();
});
chrome.tabs.onActivated.addListener(() => schedulePaStripRefresh());
chrome.storage.onChanged.addListener((changes) => {
  if (changes['patientAlerts.byPatient']) {
    _paStripStore = changes['patientAlerts.byPatient'].newValue || {};
    _paStripPrevSig = null; // force rebuild — content changed even if patient didn't
    schedulePaStripRefresh();
  }
});

// ── Urgent breach-risk strip (global — A2, panel-only) ────────────────────────
// Fifth-family global strip after #wrStrip/#rmStrip/#subRagStrip/#healthStrip/
// #paStrip (CLAUDE.md "Global demand / alert strips"). Warns when URGENT
// unactioned requests are ageing towards the April-2026 same-day contractual
// cutoff. WORKFLOW ONLY: it echoes Medicus's OWN priority flag (unvalidated
// upstream) and counts timestamps — no clinical interpretation of request
// content. See docs HAZARD-LOG (A2).
//
// Data source: it reuses the Request Monitor's cached poll state
// (suite.requestMonitor.state, written by the service-worker alarm and the RM
// strip). NO new API polling — it reads that cached state and reacts to its
// onChanged; a 60s backstop poll only re-reads storage. When the monitor is
// disabled/unconfigured there is no state and the strip stays hidden.
//
// The computation lives in shared/sla-breach-core.js (tested in
// test-sla-breach-core.js). This strip can never suppress, reorder or hide a
// request — it is purely additive. It has NO green/"all clear" state: it is
// hidden when there is nothing to report, EXCEPT the explicit fail-visible
// "urgency unknown" state when the fetched items carry no readable priority
// field (which must never look like a reassuring "zero urgent").
const slaStripEl = document.getElementById('slaBreachStrip');
const SLA_STRIP_POLL_MS = 60 * 1000;

async function fetchAndRenderSlaStrip() {
  if (document.visibilityState !== 'visible') return true;
  if (!slaStripEl || !window.RequestMonitor || !window.SlaBreachCore) return true;

  const hide = () => {
    slaStripEl.className = 'sla-strip sla-strip-hidden';
    slaStripEl.innerHTML = '';
  };

  const cfg = await window.RequestMonitor.getConfig();
  if (!cfg.enabled || !cfg.assigneeId) {
    hide();
    return true;
  }

  // Read the Request Monitor's cached poll state — no fetch of our own.
  const stR = await chrome.storage.local.get('suite.requestMonitor.state');
  const st = stR['suite.requestMonitor.state'];
  if (!st || !st.buckets) {
    hide();
    return true;
  }

  // Flatten every open new/reply request item across the four buckets, keeping
  // a bucket reference so the click-through can target the queue holding the
  // oldest urgent item.
  const flat = [];
  for (const b of window.RequestMonitor.BUCKETS) {
    const items = st.buckets[b.key]?.items;
    if (Array.isArray(items)) for (const it of items) flat.push({ it, bucket: b });
  }

  const amberMs = Math.max(0, Number(cfg.urgentAgeAmberHours) || window.SlaBreachCore.DEFAULT_AMBER_HOURS) * 3600000;
  const redMs = Math.max(0, Number(cfg.urgentAgeRedHours) || window.SlaBreachCore.DEFAULT_RED_HOURS) * 3600000;
  const now = Date.now();
  const result = window.SlaBreachCore.computeBreachRisk(
    flat.map((f) => f.it),
    { now, amberMs, redMs }
  );

  if (!result.visible) {
    hide();
    return true;
  }

  // Pick the bucket of the oldest urgent item for the click-through; default to
  // the first bucket if none can be aged (e.g. the 'unknown' state).
  let target = window.RequestMonitor.BUCKETS[0];
  let oldestAge = -1;
  for (const f of flat) {
    if (!window.SlaBreachCore.isUrgentItem(f.it)) continue;
    const age = window.SlaBreachCore.itemAgeMs(f.it, now);
    if (age !== null && age > oldestAge) {
      oldestAge = age;
      target = f.bucket;
    }
  }
  const { code, source } = await window.PracticeCode.resolve();
  const clickUrl = code
    ? window.RequestMonitor.buildClickUrl(code, target.taskType, target.status, cfg.assigneeId)
    : null;
  void source;

  let text;
  if (result.level === 'unknown') {
    text = 'Urgent requests: urgency unknown — check queue';
  } else {
    const oldest = window.SlaBreachCore.formatAge(result.oldestAgeMs);
    const plural = result.urgentCount === 1 ? '' : 's';
    text = `${result.urgentCount} urgent request${plural} unactioned` + (oldest ? ` · oldest ${oldest}` : '');
  }

  slaStripEl.className = `sla-strip sla-strip--${result.level}`;
  slaStripEl.innerHTML = `
    <span class="sla-strip-icon">⚠</span>
    <span class="sla-strip-label">SLA:</span>
    <span class="sla-strip-text">${escStrip(text)}</span>
    ${clickUrl ? `<button class="sla-strip-goto" data-sla-url="${escStrip(clickUrl)}" title="Open the request queue">Open queue →</button>` : ''}
  `;
  slaStripEl.querySelector('.sla-strip-goto[data-sla-url]')?.addEventListener('click', (e) => {
    const url = e.currentTarget.dataset.slaUrl;
    if (url) chrome.tabs.create({ url });
  });
  return true;
}

let slaStripPoller = makePoller(fetchAndRenderSlaStrip, SLA_STRIP_POLL_MS, 'sla-strip').start();
// React immediately when the Request Monitor writes fresh poll state, and when
// the breach thresholds change — the 60s poll is only a backstop.
chrome.storage.onChanged.addListener((changes) => {
  if (
    changes['suite.requestMonitor.state'] ||
    changes['suite.requestMonitor.urgentAgeAmberHours'] ||
    changes['suite.requestMonitor.urgentAgeRedHours'] ||
    changes['suite.requestMonitor.enabled'] ||
    changes['suite.requestMonitor.assigneeId']
  ) {
    fetchAndRenderSlaStrip();
  }
});

// Refresh all strips immediately when the panel becomes visible again
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') {
    fetchAndRenderStrip();
    fetchAndRenderRmStrip();
    fetchAndRenderSubRagStrip();
    fetchAndRenderHealthStrip();
    fetchAndRenderPaStrip();
    fetchAndRenderSlaStrip();
  }
});

// ── Tab visibility (suite.hiddenTabs — USER-OWNED, never profile-pushed) ─────
// Hidden tabs disappear from the nav but stay reachable via the Ctrl+K palette.
function applyTabVisibility(raw) {
  const hidden = new Set(sanitiseHiddenTabs(raw));
  _hiddenTabIds = hidden;
  document.querySelectorAll('.nav-tab').forEach((t) => {
    t.classList.toggle('nav-tab-hidden', hidden.has(t.dataset.module));
  });
  updateNavOverflow();
}
chrome.storage.onChanged.addListener((changes) => {
  if (changes['suite.hiddenTabs']) applyTabVisibility(changes['suite.hiddenTabs'].newValue);
});

// Tear down all strip pollers when the panel document goes away. The side
// panel is normally permanent, but if Chrome re-creates the document (e.g. an
// extension reload without a browser restart) the old timers would otherwise
// keep running and a fresh set would stack on top.
window.addEventListener('pagehide', () => {
  if (wrPoller) wrPoller.stop();
  if (rmPoller) rmPoller.stop();
  if (subRagPoller) subRagPoller.stop();
  if (healthPoller) healthPoller.stop();
  if (paStripPoller) paStripPoller.stop();
  if (slaStripPoller) slaStripPoller.stop();
});

// ── Boot ──────────────────────────────────────────────────────────────────────

// Sync panelDisplayPrefs from storage so the display popover reflects current settings.
// HTML attributes (data-theme etc.) are applied by shared/display-prefs.js.
function _syncPanelDisplayPrefs(p) {
  p = p || {};
  panelDisplayPrefs.theme = p.theme || 'light';
  panelDisplayPrefs.size = p.size || 'medium';
  panelDisplayPrefs.colorblind = !!p.colorblind;
}
chrome.storage.local.get('suite.display').then((r) => {
  _syncPanelDisplayPrefs(r['suite.display'] || {});
});
chrome.storage.onChanged.addListener((changes) => {
  if (changes['suite.display']) _syncPanelDisplayPrefs(changes['suite.display'].newValue || {});
});

// Wire display button
document.getElementById('displayBtn')?.addEventListener('click', (e) => {
  e.stopPropagation();
  displayOpen = !displayOpen;
  renderDisplayPopover();
});

// Wire quick-leaflet popover (leaflet search from any tab — panel only)
initQuickLeaflet({ switchModule });

// Wire per-tab help button
wireHelpButton();
wireAllTabsButton();
wireTabNavShortcuts();
wireKeyboardNav();

// ── Boot — restore last active module ────────────────────────────────────────
// Read the persisted module name and switch to it, falling back to 'slots' if
// absent, invalid, or not a real module key.
(async () => {
  const r = await chrome.storage.local.get(['panel.activeModule', 'suite.hiddenTabs']);
  const saved = r['panel.activeModule'];
  applyTabVisibility(r['suite.hiddenTabs']);
  // Guard: must be a real MODULES key, and not a hidden tab.
  const hiddenSet = new Set(sanitiseHiddenTabs(r['suite.hiddenTabs']));
  const usable = (m) => m && m in MODULES && MODULES[m] !== null && !hiddenSet.has(m);
  let startMod = usable(saved) ? saved : usable('slots') ? 'slots' : null;
  if (!startMod) {
    // Every preferred candidate hidden — first visible nav tab wins.
    for (const t of document.querySelectorAll('.nav-tab')) {
      if (usable(t.dataset.module)) {
        startMod = t.dataset.module;
        break;
      }
    }
  }
  switchModule(startMod || 'slots');

  // ── Guided tour (first-run suite walkthrough) ───────────────────────────────
  // The tour can switch tabs as it walks the suite; give it the module loader.
  // Auto-start is deferred so the boot module's first paint settles first; the
  // engine no-ops when localStorage says the current TOUR_VERSION has been seen.
  initTour({ activateModule: (name) => switchModule(name), getActiveModule: () => activeModule });
  setTimeout(maybeAutoStartTour, 900);

  // First-run setup checklist (panel-only; setupHost exists only in panel.html)
  const setupHostEl = document.getElementById('setupHost');
  if (setupHostEl) initSetup(setupHostEl);
})();

// ── Command palette (Ctrl+K) ─────────────────────────────────────────────────
initPalette();

// ── Cleanup Code Preferences: silent practice-pool contribution ─────────────
// Fire-and-forget on every panel open — never blocks anything above, never
// prompts. See shared/io/pdc-contribute.js for what this does and why it's
// safe to run without the machine ever completing the full "Publish to
// shared folder" flow in Options (that flow's own enable toggle + connect
// button live there; this just supplies the periodic trigger that doesn't
// depend on anyone opening Options). A machine that has never enabled
// contribution (suite.pdcContribute.enabled !== true) is a same-cycle no-op —
// except an established pre-v3.226.0 auto-publisher, which is migrated to
// enabled:true on first run so retiring maybeAutoPublish() doesn't silently
// stop its daily tally circulation (see migrateLegacyAutoPublisher).
(async () => {
  try {
    if (!window.PdcContribute || !window.FsHandleStore) return;

    async function resolveHandle() {
      return (
        (await window.FsHandleStore.loadFileHandle('pdcContribFile')) ||
        (await window.FsHandleStore.loadFileHandle('profileFile'))
      );
    }

    // Minimal standalone read of practice-profile.json — deliberately NOT
    // shared/io/practice-profile.js (59 KB, and pulls in every module's IO
    // file via _io() lookups this surface never needs); this is the same
    // ~10-line fetch that file's own fetchProfile() does.
    async function fetchProfile() {
      try {
        const resp = await fetch(chrome.runtime.getURL('practice-profile.json'), { cache: 'no-store' });
        if (!resp.ok) return null;
        const profile = await resp.json();
        if (profile.format !== 'medicus-suite-practice-profile') return null;
        if (!profile.profileVersion || !profile.envelope) return null;
        return profile;
      } catch (_) {
        return null;
      }
    }

    await window.PdcContribute.runPdcContribution({
      getState: async () => {
        const r = await chrome.storage.local.get(window.PdcContribute.PDC_CONTRIBUTE_STATE_KEY);
        return r[window.PdcContribute.PDC_CONTRIBUTE_STATE_KEY] || null;
      },
      setState: async (patch) => {
        const key = window.PdcContribute.PDC_CONTRIBUTE_STATE_KEY;
        const r = await chrome.storage.local.get(key);
        await chrome.storage.local.set({ [key]: Object.assign({}, r[key] || {}, patch) });
      },
      getPublisherState: async () => {
        const r = await chrome.storage.local.get('suite.practiceProfile.publisher');
        return r['suite.practiceProfile.publisher'] || null;
      },
      loadHandle: resolveHandle,
      readHandleText: async (h) => (await h.getFile()).text(),
      writeHandleText: async (h, text) => {
        const w = await h.createWritable();
        await w.write(text);
        await w.close();
      },
      fetchProfile,
      getLocalPdc: () => problemDescriptionCleanupExport(),
      mergePdc: problemDescriptionCleanupMergeForPublish,
    });
  } catch (_) {
    // Silent by contract — see pdc-contribute.js's runPdcContribution header.
  }
})();
