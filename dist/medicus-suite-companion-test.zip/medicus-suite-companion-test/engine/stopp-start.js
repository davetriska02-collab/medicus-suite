// engine/stopp-start.js — STOPP/START v3 implementable-subset engine
// © 2026 Graysbrook Ltd. Proprietary — all rights reserved. See LICENSE.
//
// Implements a structured-data-safe subset of STOPP/START v3 (2023).
// Inputs:  { drugs, problems, ageYears, egfr }
//   drugs    — array of {label:string} or strings (suite-wide drug list)
//   problems — array of {name:string} or strings (active + past problems)
//   ageYears — number | null  (age in years; age-gated criteria fail-closed
//               when null/NaN)
//   egfr     — number | null  (latest eGFR in mL/min/1.73m²; eGFR-gated
//               criteria fail-closed when null/NaN)
//
// Each returned flag: { id, kind:'stopp'|'start', criterion, detail,
//                       severity:'red'|'amber', source }
//
// Drug matching: case-insensitive substring (suite-wide convention).
// Generic names cover qualified generics; brands listed where records may
// contain only brand names. Drug class helpers use conservative term lists
// drawn from HIGH_RISK_DRUGS in visualiser-core.js (see comment per class).
//
// Exclusion notes: exclude strings are avoided except where genuinely
// necessary (per CLAUDE.md warning). Each criterion's edge-case handling
// is documented inline.
//
// REQUIRES CLINICAL SAFETY OFFICER VERIFICATION BEFORE CLINICAL RELEASE.

(function (global) {
  'use strict';

  // ── Drug-class term lists ──────────────────────────────────────────────────
  // These mirror the terms in HIGH_RISK_DRUGS (visualiser-core.js) where the
  // loading model does not allow direct reuse. Comments reference the source.

  // Full UK NSAID generic set (BNF 10.1.1 / MHRA NSAID class), kept in parity
  // with the content.js NSAIDS regex and alert-library.json. Substring,
  // case-insensitive (hasDrug). A missing generic is a SILENT STOPP miss
  // (patient on it + eGFR<50 never flags), so the list must stay complete —
  // guarded by test-term-coverage.js / term-coverage-snapshot.json.
  const NSAID_TERMS = [
    'ibuprofen',
    'naproxen',
    'diclofenac',
    'celecoxib',
    'etoricoxib',
    'meloxicam',
    'piroxicam',
    'tenoxicam',
    'indometacin', // UK spelling (BNF/dm+d)
    'indomethacin', // US/legacy spelling — not a substring of 'indometacin'
    'sulindac',
    'ketoprofen',
    'dexketoprofen',
    'tiaprofenic',
    'mefenamic',
    'tolfenamic',
    'fenoprofen',
    'aceclofenac',
    'nabumetone',
    'etodolac',
    'flurbiprofen',
    // Common UK brand names that may appear in med lists without generic name:
    'brufen', // ibuprofen
    'nurofen', // ibuprofen (OTC brand; may appear on acute prescription)
    'voltarol', // diclofenac
    'arcoxia', // etoricoxib
    'mobic', // meloxicam
    'feldene', // piroxicam
    'ponstan', // mefenamic acid
    'froben', // flurbiprofen
    'relifex', // nabumetone
    'surgam', // tiaprofenic acid
    'lodine', // etodolac
    'celebrex', // celecoxib — 2026-07-25 Keeper: brand not substring of generic; MHRA/BNF confirmed active UK brand
  ];

  // Loop diuretics — subset of HIGH_RISK_DRUGS id:'diuretic'
  const LOOP_DIURETIC_TERMS = ['furosemide', 'frusemide', 'bumetanide', 'torasemide']; // 2026-07-25 Keeper: torasemide (BNF 2.2.2 loop diuretic, active UK licence, brand Torem)

  // Benzodiazepines — standard UK generics
  const BENZO_TERMS = [
    'diazepam',
    'lorazepam',
    'temazepam',
    'nitrazepam',
    'chlordiazepoxide',
    'clonazepam',
    'alprazolam',
    'oxazepam',
    'loprazolam', // 2026-07-11 Keeper: BNF-listed UK benzo, missing from original list
    'lormetazepam', // 2026-07-11 Keeper: BNF-listed UK benzo, missing from original list
  ];

  // Z-drugs (non-benzodiazepine hypnotics)
  const ZDRUG_TERMS = [
    'zopiclone',
    'zolpidem',
    'zaleplon',
    // UK brand names:
    'zimovane', // zopiclone
    'stilnoct', // zolpidem
  ];

  // First-generation (sedating) antihistamines
  const FIRSTGEN_AH_TERMS = [
    'chlorphenamine',
    'promethazine',
    'hydroxyzine',
    'diphenhydramine',
    'cyclizine',
    'alimemazine', // 2026-07-11 Keeper: UK sedating AH (= trimeprazine), BNF 3.4.1
    'trimeprazine', // 2026-07-11 Keeper: older name for alimemazine (not substring of it)
    'brompheniramine', // 2026-07-25 Keeper: first-gen sedating AH; ACBcalc score 3; in OTC combination products
  ];

  // PPIs — from HIGH_RISK_DRUGS id:'ppi'
  const PPI_TERMS = ['omeprazole', 'lansoprazole', 'pantoprazole', 'esomeprazole', 'rabeprazole'];

  // Aspirin (low-dose antiplatelet) — from HIGH_RISK_DRUGS id:'aspirin_ap'
  // We match 'aspirin' broadly but exclude compound names that contain aspirin
  // as a component word in a safe context — however, per CLAUDE.md, we keep
  // exclusions minimal. A simple prefix check for low-dose forms:
  // Low-dose forms (dm+d generic names + word-order variant) and the UK 75mg
  // branded preparations (Nu-seals, Caprin, Micropirin) — a record may show only
  // the brand, which would otherwise silently miss the primary-prevention check.
  const ASPIRIN_TERMS = [
    'aspirin 75',
    'aspirin 300',
    'aspirin tablet',
    'aspirin dispersible',
    'aspirin gastro', // "aspirin gastro-resistant 75mg tablets" word-order variant
    'nu-seals', // AZ aspirin 75mg
    'caprin', // Pinewood aspirin 75mg (enteric-coated)
    'micropirin', // M&A Pharmachem aspirin 75mg
  ];

  // Long-acting sulfonylureas (glibenclamide, glimepiride)
  const LONG_SU_TERMS = ['glibenclamide', 'glimepiride'];

  // Statins — from HIGH_RISK_DRUGS id:'statin'
  const STATIN_TERMS = [
    'atorvastatin',
    'simvastatin',
    'rosuvastatin',
    'pravastatin',
    'fluvastatin',
    'pitavastatin', // 2026-07-11 Keeper: licensed in UK (Livazo); BNF 2.12
  ];

  // ACE inhibitors — from HIGH_RISK_DRUGS id:'acei' (first entries are ACEi).
  // Kept at parity with visualiser-core.js's ACEi list (medrev-001).
  const ACEI_TERMS = [
    'ramipril',
    'lisinopril',
    'perindopril',
    'enalapril',
    'captopril',
    'trandolapril',
    'fosinopril',
    'quinapril',
    'imidapril',
    'cilazapril',
  ];

  // ARBs — from HIGH_RISK_DRUGS id:'acei' (remaining entries are ARBs).
  // Kept at parity with visualiser-core.js's ARB list (medrev-001).
  const ARB_TERMS = [
    'candesartan',
    'losartan',
    'irbesartan',
    'valsartan',
    'olmesartan',
    'telmisartan',
    'azilsartan',
    'eprosartan',
  ];

  // Beta-blockers — from HIGH_RISK_DRUGS id:'beta_block'
  const BETA_BLOCKER_TERMS = [
    'atenolol',
    'bisoprolol',
    'propranolol',
    'metoprolol',
    'carvedilol',
    'sotalol',
    'nebivolol',
    'labetalol',
    'acebutolol', // 2026-07-11 Keeper: BNF-listed UK beta-blocker, missing from original list
    'celiprolol', // 2026-07-11 Keeper: BNF-listed UK beta-blocker, missing from original list
    'nadolol', // 2026-07-11 Keeper: BNF-listed UK beta-blocker, missing from original list
    'oxprenolol', // 2026-07-11 Keeper: BNF-listed UK beta-blocker, missing from original list
  ];

  // Anticholinergic drugs with a meaningful burden — REUSED from the shared
  // ACB table (engine/acb-scores.js, Boustani/ACBcalc scale) rather than
  // re-listed, so the two stay in lock-step (medrev-004). "Meaningful burden"
  // = ACB score ≥2 (definite/moderate anticholinergic activity); score-1
  // (mild/possible) drugs are deliberately excluded to avoid over-flagging.
  // Dual-mode load: Node require, else the browser global set by acb-scores.js
  // (loaded before this file in visualiser-core.html).
  function loadAcbTable() {
    try {
      if (typeof module !== 'undefined' && module.exports) {
        return require('./acb-scores.js').ACB_TABLE;
      }
    } catch (e) {
      /* fall through to global */
    }
    if (global && global.ACBScores && global.ACBScores.ACB_TABLE) {
      return global.ACBScores.ACB_TABLE;
    }
    return null;
  }

  const ACB_TABLE = loadAcbTable();
  // Terms for drugs with meaningful anticholinergic burden (ACB score ≥2).
  // If the shared table is unavailable (unexpected load order), this is an
  // empty list and the criterion simply does not fire (fail-closed).
  const ANTICHOLINERGIC_TERMS = (ACB_TABLE || []).filter((e) => e.score >= 2).map((e) => e.term);

  // Oral systemic corticosteroids (for the steroid bone-protection START check).
  // Hydrocortisone is DELIBERATELY excluded: as a substring it would match the
  // large volume of topical hydrocortisone creams/ointments. The cost is that
  // oral hydrocortisone (Addisonian replacement therapy — which also warrants
  // bone protection) is silently missed: a documented limitation.
  const CORTICOSTEROID_TERMS = ['prednisolone', 'deflazacort', 'methylprednisolone', 'dexamethasone'];

  // Bone-protection therapy (anti-resorptive + anabolic agents) — SHARED by the
  // osteoporosis (START H4) and corticosteroid (START H2) checks. Generic stems
  // cover salt/ester variants; brands listed because records may show only the
  // brand name.
  const BONE_THERAPY_TERMS = [
    'alendron', // stem: alendronic acid / alendronate
    'fosamax', // alendronic acid brand
    'binosto', // alendronic acid effervescent brand
    'risedron', // stem: risedronate / risedronic acid
    'actonel', // risedronate brand
    'ibandron', // stem: ibandronic acid / ibandronate
    'bonviva', // ibandronic acid brand
    'zoledron', // stem: zoledronic acid / zoledronate
    'aclasta', // zoledronic acid brand
    'pamidron', // stem: pamidronate / pamidronic acid
    'denosumab',
    'prolia', // denosumab brand
    'teriparatide',
    'forsteo', // teriparatide brand
    'movymia', // teriparatide biosimilar
    'terrosa', // teriparatide biosimilar
    'sondelbay', // teriparatide biosimilar
    'romosozumab',
    'evenity', // romosozumab brand
    'raloxifene',
    'evista', // raloxifene brand
    'abaloparatide',
    'eladynos', // abaloparatide brand
    'strontium ranelate',
  ];

  // Calcium / vitamin D supplements (for the steroid bone-protection START
  // check). Brand names dominate real records (Adcal-D3, Calcichew etc.).
  const CALCIUM_VITD_TERMS = [
    'adcal',
    'calcichew',
    'accrete',
    'evacal',
    'theical',
    'calceos',
    'natecal',
    'colecalciferol', // UK spelling (BNF/dm+d)
    'cholecalciferol', // international spelling — not a substring of 'colecalciferol'
    'fultium',
    'desunin',
    'invita d3',
    'stexerol',
    'plenachol',
    'calcium carbonate',
  ];

  // Strong / regular-use opioids (for the opioid-without-laxative check,
  // STOPP L2 / START K2). Generic names + UK brands that may appear in a record
  // without the generic. Tramadol and dihydrocodeine ARE included (regular use
  // constipates like any full agonist). WEAK opioids (codeine, co-codamol) are
  // DELIBERATELY excluded in this first version to control false positives
  // (huge, mostly-PRN prescribing volume) — extend later if flag volume
  // tolerates it. The exclusion is pinned by test-stopp-start.js.
  // NOT-opioids that substring-collide with a term below: apomorphine
  // (dopamine agonist for Parkinson's — contains 'morphine'). A drug whose
  // name hits this list never counts as an opioid.
  const STRONG_OPIOID_NOT = ['apomorphine'];
  const STRONG_OPIOID_TERMS = [
    'morphine',
    'zomorph', // morphine MR brand
    'mst continus', // morphine MR brand
    'sevredol', // morphine IR brand
    'oramorph', // morphine oral solution brand
    'mxl', // morphine MR (24h) brand
    'oxycodone',
    'oxycontin', // oxycodone MR brand
    'oxynorm', // oxycodone IR brand
    'longtec', // oxycodone MR brand
    'shortec', // oxycodone IR brand
    'reltebon', // oxycodone MR brand
    'abtard', // oxycodone MR brand
    'fentanyl',
    'durogesic', // fentanyl patch brand
    'matrifen', // fentanyl patch brand
    'mezolar', // fentanyl patch brand
    'fencino', // fentanyl patch brand
    'buprenorphine',
    'butrans', // buprenorphine patch brand
    'butec', // buprenorphine patch brand
    'transtec', // buprenorphine patch brand
    'bupeaze', // buprenorphine patch brand
    'sevodyne', // buprenorphine patch brand
    'tapentadol',
    'palexia', // tapentadol brand
    'methadone',
    'physeptone', // methadone brand
    'diamorphine',
    'pethidine',
    'tramadol',
    'zydol', // tramadol brand
    'zamadol', // tramadol brand
    'marol', // tramadol MR brand
    'maxitram', // tramadol MR brand
    'meptazinol',
    'meptid', // meptazinol brand
    'dihydrocodeine',
    'dhc continus', // dihydrocodeine MR brand
  ];

  // Laxatives — all classes (stimulant, osmotic, bulk, softener, PAMORA,
  // prokinetic). 'naloxone' is DELIBERATELY present so oxycodone/naloxone
  // combination products (Targinact) self-cover: their naloxone component
  // exists precisely to prevent opioid-induced constipation.
  const LAXATIVE_TERMS = [
    'senna',
    'senokot', // senna brand
    'lactulose',
    'duphalac', // lactulose brand
    'macrogol',
    'movicol', // macrogol brand
    'laxido', // macrogol brand
    'cosmocol', // macrogol brand
    'molaxole', // macrogol brand
    'bisacodyl',
    'dulcolax', // bisacodyl brand
    'sodium picosulfate',
    'docusate',
    'dioctyl', // docusate brand
    'docusol', // docusate brand
    'ispaghula',
    'fybogel', // ispaghula brand
    'methylcellulose',
    'celevac', // methylcellulose brand
    'sterculia',
    'normacol', // sterculia brand
    'glycerol suppositor', // stem covers suppository/suppositories
    'glycerin suppositor', // spelling variant
    'magnesium hydroxide',
    'co-danthramer',
    'co-danthrusate',
    'dantron',
    'linaclotide',
    'constella', // linaclotide brand
    'prucalopride',
    'resolor', // prucalopride brand
    'naloxegol',
    'moventig', // naloxegol brand
    'methylnaltrexone',
    'relistor', // methylnaltrexone brand
    'naldemedine',
    'rizmoic', // naldemedine brand
    'naloxone', // Targinact self-cover — see comment above
  ];

  // ── Helpers ───────────────────────────────────────────────────────────────

  // Normalise a drug to a searchable lowercase string
  function drugName(d) {
    if (typeof d === 'string') return d.toLowerCase();
    return ((d && d.label) || '').toLowerCase();
  }

  // Normalise a problem to a searchable lowercase string
  function problemName(p) {
    if (typeof p === 'string') return p.toLowerCase();
    return ((p && p.name) || '').toLowerCase();
  }

  // True if any drug in the list matches any of the given terms
  function hasDrug(drugs, terms) {
    return drugs.some((d) => {
      const n = drugName(d);
      return terms.some((t) => n.includes(t));
    });
  }

  // hasDrug variant with a not-list: a drug whose name hits any `notTerms`
  // entry is skipped entirely (apomorphine-vs-'morphine' substring collision)
  function hasDrugExcluding(drugs, terms, notTerms) {
    return drugs.some((d) => {
      const n = drugName(d);
      if (notTerms.some((x) => n.includes(x))) return false;
      return terms.some((t) => n.includes(t));
    });
  }

  // True if any problem matches any of the given terms
  function hasProblem(problems, terms) {
    return problems.some((p) => {
      const n = problemName(p);
      return terms.some((t) => n.includes(t));
    });
  }

  // True if any problem is exactly the bare token (trimmed), for abbreviations too short
  // to safely substring-match (e.g. "MI" alone, which would false-positive against
  // unrelated term lists like DIABETES_TERMS/CKD_TERMS if added to hasProblem generally)
  function hasBareProblemToken(problems, token) {
    return problems.some((p) => problemName(p).trim() === token);
  }

  // Negation/context cues that disqualify a substring problem match, so
  // "family history of osteoporosis" or "at risk of osteoporosis" does not
  // satisfy a criterion that requires the disease itself. Clause-bounding and
  // reach semantics mirror problemLabelMatchesTerm in engine/rules-engine.js —
  // keep in lock-step if either changes. The pure-history cues from that list
  // ('history of', 'past', 'previous', 'resolved') are DELIBERATELY omitted
  // here: START H4 explicitly targets a *history* of fragility fracture, and
  // osteoporosis does not resolve — treating those cues as negating would
  // silently miss exactly the patients the criterion exists for.
  const PROBLEM_NEGATION_PATTERNS = [
    /\bno\s+/,
    /\bnot\s+/,
    /\bfamily history\s+of\s+/,
    /\bfh\s+of\s+/,
    /\bat risk of\s+/,
    /\brisk of\s+/,
    /\bquery\s+/,
    // Bare '?' (query-diagnosis shorthand: '?osteoporosis'). No \b prefix —
    // there is no word boundary between start-of-string and a non-word char,
    // so /\b\?/ would never match the common leading-'?' form.
    /\?/,
  ];
  // How close (in characters) a negation cue's END must be to the matched term
  // for it to negate the match. Bounds the cue to the words immediately before
  // the term ("no significant osteoporosis") without letting an unrelated
  // earlier cue reach across the clause.
  const PROBLEM_NEGATION_REACH = 30;

  function problemMatchesTermNegationAware(label, term) {
    const l = String(label || '').toLowerCase();
    const idx = l.indexOf(term);
    if (idx < 0) return false;
    // Bound the negation scan to (a) the same clause as the match (split on
    // ; . :) and (b) cues whose end sits within PROBLEM_NEGATION_REACH chars
    // of the term — same semantics as rules-engine.js (audit H3, 2026-07-18).
    const prefix = l.slice(0, idx);
    const clauseStart = Math.max(prefix.lastIndexOf(';'), prefix.lastIndexOf('.'), prefix.lastIndexOf(':')) + 1;
    const clause = prefix.slice(clauseStart);
    return !PROBLEM_NEGATION_PATTERNS.some((rx) => {
      const g = new RegExp(rx.source, 'gi');
      let m;
      let lastEnd = -1;
      while ((m = g.exec(clause)) !== null) {
        lastEnd = m.index + m[0].length;
        if (m[0].length === 0) g.lastIndex++; // safety vs zero-width match
      }
      return lastEnd >= 0 && clause.length - lastEnd <= PROBLEM_NEGATION_REACH;
    });
  }

  // hasProblem variant that ignores matches inside a negating context
  function hasProblemNegationAware(problems, terms) {
    return problems.some((p) => {
      const n = problemName(p);
      return terms.some((t) => problemMatchesTermNegationAware(n, t));
    });
  }

  // ── Problem term lists ─────────────────────────────────────────────────────

  // Cardiovascular/cerebrovascular disease (for aspirin primary-prevention check)
  const CV_DISEASE_TERMS = [
    'coronary',
    'ischaemic heart',
    'ischemic heart',
    'myocardial infarction',
    'mi ',
    'angina',
    'heart failure',
    'atrial fibrillation',
    'stroke',
    'tia',
    'transient ischaemic',
    'peripheral arterial',
    'peripheral vascular',
    'carotid',
    'aortic',
    'cardiac arrest',
    'revascularisation',
    'revascularization',
    'stent',
    'cabg',
    'bypass',
  ];

  // Coronary / ischaemic heart disease (for statin START)
  const IHD_TERMS = [
    'coronary artery disease',
    'ischaemic heart disease',
    'ischemic heart disease',
    'myocardial infarction',
    'angina',
    'stemi',
    'nstemi',
    'acute coronary',
    'unstable angina',
    'stable angina',
    'cabg',
    'percutaneous coronary',
    'coronary stent',
  ];

  // Diabetes
  const DIABETES_TERMS = [
    'type 2 diabetes',
    'type 1 diabetes',
    'diabetes mellitus',
    'insulin-dependent diabetes',
    'non-insulin-dependent diabetes',
    'diabetic',
    't2dm',
    't1dm',
  ];

  // CKD
  const CKD_TERMS = [
    'chronic kidney disease',
    'ckd',
    'renal failure',
    'renal impairment',
    'nephropathy',
    'end stage renal',
  ];

  // Myocardial infarction (for beta-blocker START)
  const MI_TERMS = ['myocardial infarction', 'mi ', 'stemi', 'nstemi', 'heart attack'];

  // Osteoporosis / fragility fracture (for bone-protection START H4).
  // Deliberately NOT bare 'fracture' (would flood on traumatic fractures) and
  // NOT 'osteopenia' (H4 requires established osteoporosis, T-score ≤ -2.5).
  const OSTEOPOROSIS_TERMS = ['osteoporosis', 'osteoporotic', 'fragility fracture'];

  // Digoxin
  const DIGOXIN_TERMS = ['digoxin'];

  // Metformin
  const METFORMIN_TERMS = ['metformin'];

  // ── Main function ─────────────────────────────────────────────────────────

  /**
   * Compute STOPP/START v3 flags from a structured patient snapshot.
   *
   * @param {{ drugs: Array, problems: Array, ageYears: number|null, egfr: number|null }} opts
   * @returns {Array<{ id:string, kind:'stopp'|'start', criterion:string, detail:string, severity:'red'|'amber', source:string }>}
   */
  function computeStoppStart({ drugs = [], problems = [], ageYears = null, egfr = null }) {
    const flags = [];

    const age = typeof ageYears === 'number' && isFinite(ageYears) ? ageYears : null;
    const gfr = typeof egfr === 'number' && isFinite(egfr) ? egfr : null;
    const ageKnown = age !== null;
    const gfrKnown = gfr !== null;

    // ── STOPP ─────────────────────────────────────────────────────────────────

    // STOPP 1: NSAID with eGFR <50 (red)
    // Fail-closed: no flag if eGFR unknown.
    if (hasDrug(drugs, NSAID_TERMS) && gfrKnown && gfr < 50) {
      flags.push({
        id: 'stopp_nsaid_ckd',
        kind: 'stopp',
        criterion: 'NSAID with eGFR <50 mL/min/1.73m²',
        detail:
          `NSAID detected; latest eGFR ${gfr.toFixed(0)} mL/min/1.73m². NSAIDs reduce renal perfusion ` +
          'and are potentially inappropriate in moderate-to-severe CKD (eGFR <50). ' +
          'Risk of AKI, hyperkalaemia, and accelerated GFR decline.',
        severity: 'red',
        source: 'STOPP/START v3 (2023) — Section H: Renal',
      });
    }

    // STOPP 2: NSAID + loop diuretic (amber)
    if (hasDrug(drugs, NSAID_TERMS) && hasDrug(drugs, LOOP_DIURETIC_TERMS)) {
      flags.push({
        id: 'stopp_nsaid_loop',
        kind: 'stopp',
        criterion: 'NSAID co-prescribed with loop diuretic',
        detail:
          'NSAID + loop diuretic combination: NSAIDs antagonise the natriuretic effect of diuretics and ' +
          'increase risk of AKI, fluid retention, and cardiac decompensation. Review NSAID indication.',
        severity: 'amber',
        source: 'STOPP/START v3 (2023) — Section H: Renal',
      });
    }

    // STOPP 3: First-generation antihistamine in age ≥65 (amber)
    // Fail-closed: if age unknown, flag does NOT fire.
    if (hasDrug(drugs, FIRSTGEN_AH_TERMS) && ageKnown && age >= 65) {
      // Identify which antihistamine matched for the detail text
      const matched = FIRSTGEN_AH_TERMS.find((t) => drugs.some((d) => drugName(d).includes(t)));
      flags.push({
        id: 'stopp_firstgen_ah_elderly',
        kind: 'stopp',
        criterion: 'First-generation antihistamine in patient aged ≥65',
        detail:
          `Sedating antihistamine (${matched || 'first-generation'}) detected in patient aged ` +
          `${Math.floor(age)}y. First-generation antihistamines have significant anticholinergic ` +
          'activity and cause sedation, falls, urinary retention, and cognitive impairment in older adults. ' +
          'Prefer a non-sedating alternative (cetirizine, loratadine) if an antihistamine is required.',
        severity: 'amber',
        source: 'STOPP/START v3 (2023) — Section D: CNS/Psychotropic',
      });
    }

    // STOPP 4: Benzodiazepine in age ≥65 (amber)
    // Duration unknowable from a snapshot — caveat included in detail.
    // Fail-closed: if age unknown, flag does NOT fire.
    if (hasDrug(drugs, BENZO_TERMS) && ageKnown && age >= 65) {
      const matched = BENZO_TERMS.find((t) => drugs.some((d) => drugName(d).includes(t)));
      flags.push({
        id: 'stopp_benzo_elderly',
        kind: 'stopp',
        criterion: 'Benzodiazepine in patient aged ≥65',
        detail:
          `Benzodiazepine (${matched || 'benzodiazepine'}) detected in patient aged ${Math.floor(age)}y. ` +
          'In older adults, benzodiazepines increase risk of falls, fractures, motor vehicle accidents, ' +
          'and cognitive impairment. Review duration: ≥2 weeks for insomnia is potentially inappropriate. ' +
          'Note: duration cannot be determined from this point-in-time snapshot — verify against the live record.',
        severity: 'amber',
        source: 'STOPP/START v3 (2023) — Section D: CNS/Psychotropic',
      });
    }

    // STOPP 5: Z-drug in age ≥65 (amber)
    // Same duration caveat.
    // Fail-closed: if age unknown, flag does NOT fire.
    if (hasDrug(drugs, ZDRUG_TERMS) && ageKnown && age >= 65) {
      const matched = ZDRUG_TERMS.find((t) => drugs.some((d) => drugName(d).includes(t)));
      flags.push({
        id: 'stopp_zdrug_elderly',
        kind: 'stopp',
        criterion: 'Z-drug (non-benzodiazepine hypnotic) in patient aged ≥65',
        detail:
          `Z-drug (${matched || 'zopiclone/zolpidem'}) detected in patient aged ${Math.floor(age)}y. ` +
          'Z-drugs have similar adverse effects to benzodiazepines in older adults (falls, cognitive impairment). ' +
          'Review duration: ≥2 weeks for sleep is potentially inappropriate. ' +
          'Duration cannot be determined from this point-in-time snapshot — verify against the live record.',
        severity: 'amber',
        source: 'STOPP/START v3 (2023) — Section D: CNS/Psychotropic',
      });
    }

    // STOPP 6: Digoxin with eGFR <30 (red)
    // Fail-closed: if eGFR unknown, flag does NOT fire.
    if (hasDrug(drugs, DIGOXIN_TERMS) && gfrKnown && gfr < 30) {
      flags.push({
        id: 'stopp_digoxin_gfr30',
        kind: 'stopp',
        criterion: 'Digoxin with eGFR <30 mL/min/1.73m²',
        detail:
          `Digoxin detected; latest eGFR ${gfr.toFixed(0)} mL/min/1.73m². Digoxin is renally cleared; ` +
          'accumulation at eGFR <30 risks toxicity (arrhythmia, bradycardia, nausea, confusion). ' +
          'Review dose — therapeutic drug monitoring is essential.',
        severity: 'red',
        source: 'STOPP/START v3 (2023) — Section H: Renal',
      });
    }

    // STOPP 7: Metformin with eGFR <30 (red)
    // Fail-closed: if eGFR unknown, flag does NOT fire.
    if (hasDrug(drugs, METFORMIN_TERMS) && gfrKnown && gfr < 30) {
      flags.push({
        id: 'stopp_metformin_gfr30',
        kind: 'stopp',
        criterion: 'Metformin with eGFR <30 mL/min/1.73m²',
        detail:
          `Metformin detected; latest eGFR ${gfr.toFixed(0)} mL/min/1.73m². Metformin is contraindicated ` +
          'at eGFR <30 (risk of lactic acidosis). Refer to NICE NG28 / BNF: reduce dose at eGFR 30–45, ' +
          'withhold at eGFR <30.',
        severity: 'red',
        source: 'STOPP/START v3 (2023) — Section H: Renal',
      });
    }

    // STOPP 8: PPI present — review indication and duration (amber)
    // Conservative: flags presence only. Cannot assess indication from snapshot.
    if (hasDrug(drugs, PPI_TERMS)) {
      flags.push({
        id: 'stopp_ppi_review',
        kind: 'stopp',
        criterion: 'Proton pump inhibitor — review indication and duration',
        detail:
          'PPI detected. Review indication and duration: >8 weeks of PPI without an ongoing clear indication ' +
          "(e.g. Barrett's oesophagus, active ulcer, NSAID/antiplatelet + GI risk factor) is potentially " +
          'inappropriate. Long-term PPI use is associated with hypomagnesaemia, C. difficile, fractures, and ' +
          'B12 deficiency. Duration cannot be determined from this snapshot — verify against the live record.',
        severity: 'amber',
        source: 'STOPP/START v3 (2023) — Section F: GI',
      });
    }

    // STOPP 9: Aspirin with no cardiovascular/cerebrovascular disease problem
    //          (primary prevention — amber)
    // Approach: if aspirin is present AND no CV/cerebrovascular disease found
    // in the problem list, flag as possible primary prevention.
    // Conservative: the terms list for CV disease is broad to minimise
    // false positives. If the problem list contains any CV term, no flag.
    if (
      hasDrug(drugs, ASPIRIN_TERMS) &&
      !hasProblem(problems, CV_DISEASE_TERMS) &&
      !hasBareProblemToken(problems, 'mi')
    ) {
      flags.push({
        id: 'stopp_aspirin_primary_prev',
        kind: 'stopp',
        criterion: 'Aspirin without documented cardiovascular/cerebrovascular disease',
        detail:
          'Low-dose aspirin detected without a coded cardiovascular or cerebrovascular disease indication. ' +
          'Aspirin for primary prevention is not recommended (NICE NG204, ESC 2021): bleeding risk exceeds ' +
          'benefit in patients without established CV disease. If aspirin is genuinely indicated (e.g. ACS ' +
          'within last 12 months not yet coded), review the problem list for completeness.',
        severity: 'amber',
        source: 'STOPP/START v3 (2023) — Section I: Cardiovascular',
      });
    }

    // STOPP 10: Long-acting sulfonylurea in age ≥65 (amber)
    // Fail-closed: if age unknown, flag does NOT fire.
    if (hasDrug(drugs, LONG_SU_TERMS) && ageKnown && age >= 65) {
      const matched = LONG_SU_TERMS.find((t) => drugs.some((d) => drugName(d).includes(t)));
      flags.push({
        id: 'stopp_long_su_elderly',
        kind: 'stopp',
        criterion: 'Long-acting sulfonylurea in patient aged ≥65',
        detail:
          `Long-acting sulfonylurea (${matched || 'glibenclamide/glimepiride'}) detected in patient aged ` +
          `${Math.floor(age)}y. Long-acting sulfonylureas carry sustained hypoglycaemia risk in older adults ` +
          '(impaired counter-regulation, reduced food intake, renal clearance decline). ' +
          'Prefer a shorter-acting agent (gliclazide) or alternative class.',
        severity: 'amber',
        source: 'STOPP/START v3 (2023) — Section J: Endocrine',
      });
    }

    // STOPP 10b: Anticholinergic burden in age ≥65 (amber)
    // Fires when an older patient (age ≥65) is on one or more drugs with a
    // meaningful anticholinergic burden (ACB score ≥2). Anticholinergic load
    // in older adults raises the risk of cognitive impairment, delirium,
    // falls, constipation, and urinary retention. Term set is REUSED from the
    // shared ACB table (engine/acb-scores.js). Fail-closed: if age unknown or
    // the ACB table is unavailable, this flag does NOT fire.
    if (ANTICHOLINERGIC_TERMS.length && hasDrug(drugs, ANTICHOLINERGIC_TERMS) && ageKnown && age >= 65) {
      const matched = ANTICHOLINERGIC_TERMS.filter((t) => drugs.some((d) => drugName(d).includes(t)));
      const matchedList = Array.from(new Set(matched)).join(', ');
      flags.push({
        id: 'stopp-anticholinergic-elderly',
        kind: 'stopp',
        criterion: 'Drug(s) with meaningful anticholinergic burden in patient aged ≥65',
        detail:
          `Anticholinergic drug(s) detected (${matchedList || 'anticholinergic'}) in patient aged ` +
          `${Math.floor(age)}y. Cumulative anticholinergic burden in older adults increases the risk of ` +
          'cognitive impairment, delirium, falls, constipation, urinary retention, and dry mouth/eyes. ' +
          'Review the total anticholinergic load (ACB score) and seek lower-burden alternatives where possible. ' +
          'Note: burden is cumulative across the whole drug list — assess the full regimen, not this drug alone.',
        severity: 'amber',
        source: 'STOPP/START v3 (O’Mahony 2023) — Section B: CNS/Psychotropic (anticholinergic burden)',
      });
    }

    // STOPP L2 / START K2 (2026-08-22 Keeper): regular strong opioid without
    // concomitant laxative (amber). DEGRADED presence-only check: regular-vs-PRN
    // dosing is unknowable from a snapshot, so that caveat is carried in the
    // detail text. Weak opioids (codeine/co-codamol) deliberately excluded —
    // see STRONG_OPIOID_TERMS comment.
    if (hasDrugExcluding(drugs, STRONG_OPIOID_TERMS, STRONG_OPIOID_NOT) && !hasDrug(drugs, LAXATIVE_TERMS)) {
      flags.push({
        id: 'stopp_opioid_no_laxative',
        kind: 'stopp',
        criterion: 'Regular strong opioid without concomitant laxative',
        detail:
          'Strong opioid detected with no laxative co-prescribed. Opioid-induced constipation affects ' +
          '40–80% of patients on regular opioids; in older adults it causes impaction, overflow ' +
          'incontinence, delirium, and admission. Criterion applies to DAILY REGULAR opioids — verify ' +
          'this is not PRN-only use (dosing pattern cannot be determined from this snapshot). ' +
          'Note: over-the-counter laxatives (e.g. senna bought OTC) do not appear in the medication list.',
        severity: 'amber',
        source: 'STOPP/START v3 (2023) — Section L: Analgesics (L2) / START Section K (K2)',
      });
    }

    // ── START ─────────────────────────────────────────────────────────────────

    // START 11: Coronary/IHD present AND no statin (amber)
    if (hasProblem(problems, IHD_TERMS) && !hasDrug(drugs, STATIN_TERMS)) {
      flags.push({
        id: 'start_statin_ihd',
        kind: 'start',
        criterion: 'Consider statin in established coronary/ischaemic heart disease',
        detail:
          'Coronary or ischaemic heart disease problem coded but no statin detected. ' +
          'Statins reduce mortality and major cardiovascular events in established IHD (NICE CG181). ' +
          'Check whether statin therapy was declined, not tolerated, or is prescribed elsewhere.',
        severity: 'amber',
        source: 'STOPP/START v3 (2023) — START Section A: Cardiovascular',
      });
    }

    // START 12: Diabetes + CKD (or eGFR <60) AND no ACEi/ARB (amber)
    // Fail-closed on eGFR gate: fires if CKD problem present OR eGFR <60.
    // Does not fire if neither CKD problem nor eGFR available.
    const hasDiabetes = hasProblem(problems, DIABETES_TERMS);
    const hasCkdProblem = hasProblem(problems, CKD_TERMS);
    const gfrBelow60 = gfrKnown && gfr < 60;
    const hasAceiOrArb = hasDrug(drugs, ACEI_TERMS) || hasDrug(drugs, ARB_TERMS);

    if (hasDiabetes && (hasCkdProblem || gfrBelow60) && !hasAceiOrArb) {
      const gfrNote = gfrKnown ? ` (latest eGFR ${gfr.toFixed(0)})` : '';
      flags.push({
        id: 'start_acei_arb_dm_ckd',
        kind: 'start',
        criterion: 'Consider ACE inhibitor or ARB in diabetes with CKD',
        detail:
          `Diabetes coded with CKD${gfrNote} but no ACE inhibitor or ARB detected. ` +
          'ACEi/ARB reduces the rate of progression to end-stage renal disease in diabetic nephropathy ' +
          '(NICE NG28). Check for contraindication or intolerance.',
        severity: 'amber',
        source: 'STOPP/START v3 (2023) — START Section A: Cardiovascular',
      });
    }

    // START 13: Myocardial infarction AND no beta-blocker (amber)
    if (
      (hasProblem(problems, MI_TERMS) || hasBareProblemToken(problems, 'mi')) &&
      !hasDrug(drugs, BETA_BLOCKER_TERMS)
    ) {
      flags.push({
        id: 'start_bb_post_mi',
        kind: 'start',
        criterion: 'Consider beta-blocker following myocardial infarction',
        detail:
          'Myocardial infarction problem coded but no beta-blocker detected. ' +
          'Beta-blockers reduce mortality post-MI (NICE CG172 / ESC guidelines). ' +
          'If not prescribed, check for contraindication (asthma, severe bradycardia, cardiogenic shock) ' +
          'or whether it was discontinued.',
        severity: 'amber',
        source: 'STOPP/START v3 (2023) — START Section A: Cardiovascular',
      });
    }

    // START H4 (2026-08-22 Keeper): osteoporosis / fragility fracture AND no
    // bone-protection therapy (amber). Problem match is negation-aware so
    // "family history of osteoporosis" / "at risk of osteoporosis" do not fire
    // (see hasProblemNegationAware — pure-history cues deliberately still match).
    if (hasProblemNegationAware(problems, OSTEOPOROSIS_TERMS) && !hasDrug(drugs, BONE_THERAPY_TERMS)) {
      flags.push({
        id: 'start_bone_protection_osteoporosis',
        kind: 'start',
        criterion: 'Consider bone-protection therapy in osteoporosis / fragility fracture',
        detail:
          'Osteoporosis or fragility fracture coded but no bone-protection therapy (bisphosphonate, ' +
          'denosumab, or other anti-resorptive/anabolic agent) detected. Antiresorptive therapy roughly ' +
          'halves re-fracture risk (NOGG / NICE TA464). Caution: denosumab (6-monthly injection) and ' +
          'IV zoledronate (annual infusion) are often clinic-administered and may not appear in the ' +
          'practice medication list — verify before acting. Exemption per the v3 criterion: bone ' +
          'protection may reasonably be withheld where estimated life expectancy is under 1 year ' +
          '(clinical judgement).',
        severity: 'amber',
        source: 'STOPP/START v3 (2023) — START Section H: Musculoskeletal (H4)',
      });
    }

    // START H2 (2026-08-22 Keeper): systemic corticosteroid AND no bone
    // protection AND no calcium/vitamin D (amber). DEGRADED variant: H2 applies
    // to corticosteroid courses expected to run ≥3 months, but course duration
    // is unknowable from a snapshot — that caveat is carried in the detail
    // text. Hydrocortisone is deliberately absent from CORTICOSTEROID_TERMS
    // (topical substring; oral Addisonian replacement is a documented miss —
    // see the term-list comment).
    if (
      hasDrug(drugs, CORTICOSTEROID_TERMS) &&
      !hasDrug(drugs, BONE_THERAPY_TERMS) &&
      !hasDrug(drugs, CALCIUM_VITD_TERMS)
    ) {
      flags.push({
        id: 'start_bone_protection_steroid',
        kind: 'start',
        criterion: 'Consider bone protection with long-term systemic corticosteroid',
        detail:
          'Systemic corticosteroid detected without bone-protection therapy or calcium/vitamin D ' +
          'supplementation. Corticosteroid-induced bone loss is most rapid in the first months of ' +
          'treatment. Course duration cannot be determined from this snapshot — applies to ' +
          'corticosteroid courses expected to run ≥3 months; verify against the live record.',
        severity: 'amber',
        source: 'STOPP/START v3 (2023) — START Section H: Musculoskeletal (H2)',
      });
    }

    return flags;
  }

  // ── Module export (dual-mode: Node require OR browser global) ──────────────
  // SPEC is the published identifier of the criteria set implemented here. Read by
  // the CQC readiness disclosure so the named version cannot drift from the engine.
  const SPEC = { name: 'STOPP/START', version: 'v3 (2023)', source: "O'Mahony et al., Age and Ageing 2023" };
  const api = { computeStoppStart, SPEC };
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    global.StoppStart = api;
  }
})(typeof window !== 'undefined' ? window : global);
