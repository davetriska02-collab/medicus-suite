// © 2026 Graysbrook Ltd. Proprietary — all rights reserved. See LICENSE.
// Medicus Suite — Today module (morning command centre)
//
// A headline sentence + four data cards + one action card give a
// single-glance answer to "what needs you now?" before clinic starts.
//
//  0. Headline      — one plain-English sentence rolled up from the cards
//                      below (today-headline.js, pure/testable). No new fetch.
//  1. Waiting Room  — arrived patients, max wait (amber ≥10, red ≥20). Poll 30s.
//  2. Triage Load   — RequestMonitor bucket counts as pills. Poll 60s.
//  3. Demand Today  — medical + admin submission counts with threshold washes. Poll 60s.
//  4. Slots Today   — available slots for today (lean local fetch). Poll 60s.
//  5. Morning Sweep — reads sweep.lastRun (TTL 2h); shows status + Open Sweep button.
//
// No new chrome.storage keys — read-only consumers of keys owned by other modules.

'use strict';

import { buildHeadline } from './today-headline.js';
import { hasEnabledRules, buildBreaches } from '../slots/slots-alert-core.js';
import { isActionNeeded } from '../sweep/sweep-core.js';
import { windowTaskList, ledgerSeriesForDay, demandBaseline, baselineLine } from '../submissions/submissions-core.js';
import { recordTaskLists } from '../submissions/submissions-ledger.js';
import { followupCounts } from '../followups/followups-core.js';

// ── Constants ─────────────────────────────────────────────────────────────────

const WR_POLL_MS = 30 * 1000;
const DEMAND_POLL_MS = 60 * 1000;
const SWEEP_LAST_RUN_TTL_MS = 2 * 60 * 60 * 1000;

const DEFAULT_SUB_THRESHOLDS = {
  medical: { amber: 30, red: 60, enabled: false },
  admin: { amber: 20, red: 40, enabled: false },
};

// ── Module state ──────────────────────────────────────────────────────────────

let container = null;
let _timers = [];

// Card-level data state
let _wrData = null; // { patients: [], error: null }
let _rmData = null; // { buckets: {}, configured: bool, error: null }
let _demandData = null; // { medical: n, admin: n, thresholds: {}, error: null }
let _slotsData = null; // { count: n, error: null, breaches: [{ typeName, threshold, count, level }] }
let _sweepData = null; // { lastRun: obj|null }
let _alertsData = null; // [{ ts, channel, level, label }, ...]

// ── Helpers ───────────────────────────────────────────────────────────────────

function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function todayISO() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function navTo(module) {
  document.querySelector(`.nav-tab[data-module="${module}"]`)?.click();
}

function openSetup() {
  if (document.getElementById('setupHost')) {
    document.dispatchEvent(new CustomEvent('suite:open-setup'));
  } else {
    chrome.tabs.create({ url: chrome.runtime.getURL('options/options.html#sect-suite') });
  }
}

// Decision F: human-readable error copy, raw message preserved in title attr
function errMsg(raw) {
  const human = 'Couldn’t reach Medicus — retrying automatically';
  const glyph = `<svg class="today-error-glyph" width="10" height="10" viewBox="0 0 10 10" fill="none" aria-hidden="true"><circle cx="5" cy="5" r="4" stroke="currentColor" stroke-width="1.5"/><line x1="5" y1="3" x2="5" y2="5.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><circle cx="5" cy="7.2" r="0.7" fill="currentColor"/></svg>`;
  return `<span class="today-card-error" title="${esc(raw)}">${glyph}<span class="today-card-error-copy">${esc(human)}</span></span>`;
}

function errMsgInline(raw) {
  const human = 'Couldn’t reach Medicus — retrying automatically';
  const glyph = `<svg class="today-error-glyph" width="10" height="10" viewBox="0 0 10 10" fill="none" aria-hidden="true"><circle cx="5" cy="5" r="4" stroke="currentColor" stroke-width="1.5"/><line x1="5" y1="3" x2="5" y2="5.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><circle cx="5" cy="7.2" r="0.7" fill="currentColor"/></svg>`;
  return `<span class="today-card-error today-card-error--inline" title="${esc(raw)}">${glyph}<span class="today-card-error-copy">${esc(human)}</span></span>`;
}

// Oldest unanswered new-request across all new-request buckets (ms epoch), or
// null when none carry a parseable createdAt. This is the card's altitude over
// the strip: the strip says how many, the card says how long the worst has waited.
function oldestUnanswered(buckets) {
  let oldestMs = null;
  for (const b of window.RequestMonitor?.BUCKETS || []) {
    if (b.status !== 'new-request') continue;
    for (const it of buckets?.[b.key]?.items || []) {
      const t = it.createdAt ? new Date(it.createdAt).getTime() : NaN;
      if (!isNaN(t) && (oldestMs === null || t < oldestMs)) oldestMs = t;
    }
  }
  return oldestMs;
}

function fmtAge(ms) {
  const mins = Math.max(0, Math.round((Date.now() - ms) / 60000));
  if (mins < 60) return `${mins}m`;
  const h = Math.floor(mins / 60);
  const d = Math.floor(h / 24);
  if (d >= 2) return `${d}d`;
  return `${h}h ${String(mins % 60).padStart(2, '0')}m`;
}

// ── Fetch: Waiting Room ────────────────────────────────────────────────────────

async function fetchWr() {
  if (document.visibilityState !== 'visible') return;
  try {
    // Shared memoised fetcher (audit M10) — coalesces with panel.js's WR strip
    // poll of the same endpoint. Practice code is re-resolved inside.
    const { raw, code } = await window.AppointmentsFeed.fetchRaw({ module: 'today-wr' });
    if (!code) {
      _wrData = { patients: [], error: null, noCode: true };
      renderCard('wr');
      renderHeadline();
      return;
    }
    const now = Date.now();
    const patients = window.AppointmentsFeed.arrivedEntries(raw)
      .map((e) => {
        const ms = e.startDateTime ? new Date(e.startDateTime).getTime() : null;
        const mins = ms && !isNaN(ms) ? Math.max(0, Math.round((now - ms) / 60000)) : null;
        return { name: e.patient?.name ?? 'Unknown', mins };
      })
      .sort((a, b) => (b.mins ?? 0) - (a.mins ?? 0));
    _wrData = { patients, error: null };
  } catch (e) {
    _wrData = { patients: [], error: e.message || 'Fetch failed' };
  }
  renderCard('wr');
  renderHeadline();
}

// ── Fetch: Triage / Request Monitor ───────────────────────────────────────────

async function fetchRm() {
  if (document.visibilityState !== 'visible') return;
  try {
    if (!window.RequestMonitor) {
      _rmData = { configured: false, error: null };
      renderCard('rm');
      renderHeadline();
      return;
    }
    const cfg = await window.RequestMonitor.getConfig();
    if (!cfg.enabled || !cfg.assigneeId) {
      _rmData = { configured: false, error: null };
      renderCard('rm');
      renderHeadline();
      return;
    }
    const { code, source } = await window.PracticeCode.resolve();
    if (!code) {
      _rmData = { configured: true, buckets: {}, error: 'No practice code' };
      renderCard('rm');
      renderHeadline();
      return;
    }
    const result = await window.RequestMonitor.pollAll(code, cfg.assigneeId, {
      fetch: (url, init) => window.ApiDiag.fetch({ module: 'today-rm', url, code, codeSource: source, init }),
    });
    _rmData = { configured: true, buckets: result.buckets || {}, error: result.error || null };
  } catch (e) {
    _rmData = { configured: true, buckets: {}, error: e.message || 'Fetch failed' };
  }
  renderCard('rm');
  renderHeadline();
}

// ── Fetch: Demand Today ────────────────────────────────────────────────────────

async function fetchDemand() {
  if (document.visibilityState !== 'visible') return;
  try {
    const stored = await chrome.storage.local.get('submissions.thresholds');
    const thresholds = { ...DEFAULT_SUB_THRESHOLDS, ...(stored['submissions.thresholds'] || {}) };
    const { code, source } = await window.PracticeCode.resolve();
    if (!code) {
      _demandData = { medical: null, admin: null, thresholds, error: null, noCode: true };
      renderCard('demand');
      renderHeadline();
      return;
    }
    const today = todayISO();
    let baseline = null;
    const [medRes, admRes] = await Promise.allSettled([
      window.ApiDiag.fetch({
        module: 'today-demand',
        url: `https://${code}.api.england.medicus.health/tasks/data/medical_patient_request_task/task-list?createdAt_startDate=${today}&createdAt_endDate=${today}`,
        code,
        codeSource: source,
      }).then((r) => r.json()),
      window.ApiDiag.fetch({
        module: 'today-demand',
        url: `https://${code}.api.england.medicus.health/tasks/data/admin_patient_request_task/task-list?createdAt_startDate=${today}&createdAt_endDate=${today}`,
        code,
        codeSource: source,
      }).then((r) => r.json()),
    ]);
    // Route both responses through windowTaskList so a server-side change to
    // the createdAt_* filter (silently ignored params → default open-task view)
    // degrades to an honest count + visible warning, not a quietly wrong number.
    const medW = medRes.status === 'fulfilled' ? windowTaskList(medRes.value, today, today) : null;
    const admW = admRes.status === 'fulfilled' ? windowTaskList(admRes.value, today, today) : null;
    let medical = medW ? medW.tasks.length : null;
    let admin = admW ? admW.tasks.length : null;
    // Count from the day ledger, not the raw response: the task-list only
    // contains OPEN tasks (completed requests leave the table — v3.153.0), so
    // the raw count erodes as the team works. The ledger remembers every task
    // seen today, so "received today" survives completion.
    try {
      const byKey = {};
      if (medW) byKey.medical = medW.tasks;
      if (admW) byKey.admin = admW.tasks;
      const ledger = await recordTaskLists(byKey);
      const s = ledgerSeriesForDay(ledger, today, ['medical', 'admin']);
      if (medW) medical = s.medical.total;
      if (admW) admin = s.admin.total;
      // Same-weekday baseline read (null until enough watched history) —
      // cumulative to the CURRENT hour, so a half-day is compared honestly.
      baseline = demandBaseline(ledger, today, new Date().getHours(), ['medical', 'admin']);
    } catch (_) {
      // Storage failure — fall back to the live (open-only) counts above.
    }
    const dataWarn =
      medW?.filterIgnored || admW?.filterIgnored
        ? 'Medicus ignored the date filter — counts may miss completed work'
        : medW?.truncated || admW?.truncated
          ? 'Medicus sent a partial task page — counts may be low'
          : null;
    const error =
      medRes.status === 'rejected' || admRes.status === 'rejected'
        ? medRes.reason?.message || admRes.reason?.message || 'Fetch failed'
        : null;
    _demandData = { medical, admin, thresholds, error, dataWarn, baseline };
  } catch (e) {
    _demandData = {
      medical: null,
      admin: null,
      thresholds: DEFAULT_SUB_THRESHOLDS,
      error: e.message || 'Fetch failed',
    };
  }
  renderCard('demand');
  renderHeadline();
}

// ── Fetch: Slots ──────────────────────────────────────────────────────────────
// Lean local implementation against the same embedded-overview endpoint as slots.js.
// Counts entries where diaryEntryType.value === 'slot' and start is not in the past.
//
// Item 9: also reads 'slots.alertRules' — a key OWNED by the Slots module
// (chrome.storage.local, per-appointment-type "alert if fewer than N left"
// rules) — read-only, the same pattern this card already uses for other
// modules' keys. Per-type counts are only bothered with when at least one
// rule is enabled (hasEnabledRules gate), so a practice with no alert rules
// configured pays no extra cost on this already-lean poll.

async function fetchSlots() {
  if (document.visibilityState !== 'visible') return;
  try {
    const { code, source } = await window.PracticeCode.resolve();
    if (!code) {
      _slotsData = { count: null, error: null, noCode: true, breaches: [] };
      renderCard('slots');
      renderHeadline();
      return;
    }
    const stored = await chrome.storage.local.get('slots.alertRules');
    const alertRules = stored['slots.alertRules'] || [];
    const trackBreaches = hasEnabledRules(alertRules);

    const today = todayISO();
    const url = `https://${code}.api.england.medicus.health/scheduling/data/appointment-book/embedded-overview?date=${today}&filterByUsualLocation=false`;
    const r = await window.ApiDiag.fetch({ module: 'today-slots', url, code, codeSource: source });
    const raw = await r.json();
    const now = new Date();
    let count = 0;
    const byType = trackBreaches ? {} : null;
    for (const staff of raw.staffSchedules || []) {
      for (const session of staff.schedule || []) {
        for (const entry of session.entries || []) {
          if (entry.diaryEntryType?.value !== 'slot') continue;
          if (entry.startDateTime && new Date(entry.startDateTime) < now) continue;
          count++;
          if (byType) {
            const type = entry.appointmentType?.name || 'Unknown';
            byType[type] = (byType[type] || 0) + 1;
          }
        }
      }
    }
    const breaches = byType ? buildBreaches(alertRules, byType) : [];
    _slotsData = { count, error: null, breaches };
  } catch (e) {
    _slotsData = { count: null, error: e.message || 'Fetch failed', breaches: [] };
  }
  renderCard('slots');
  renderHeadline();
}

// ── Fetch: Sweep last run ─────────────────────────────────────────────────────

async function fetchSweep() {
  try {
    const r = await chrome.storage.local.get('sweep.lastRun');
    const d = r['sweep.lastRun'];
    if (!d || typeof d !== 'object') {
      _sweepData = { lastRun: null };
    } else {
      const runAt = typeof d.runAt === 'string' ? new Date(d.runAt).getTime() : d.runAt;
      if (!runAt || Date.now() - runAt > SWEEP_LAST_RUN_TTL_MS) {
        _sweepData = { lastRun: null };
      } else {
        _sweepData = { lastRun: d };
      }
    }
  } catch (_) {
    _sweepData = { lastRun: null };
  }
  renderCard('sweep');
  // Recent Alerts borrows sweep provenance for its empty state — keep it in sync.
  renderCard('alerts');
  renderHeadline();
}

// ── Fetch: Alert log ─────────────────────────────────────────────────────────

async function fetchAlerts() {
  try {
    const r = await chrome.storage.local.get('suite.alertLog');
    const log = Array.isArray(r['suite.alertLog']) ? r['suite.alertLog'] : [];
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    const todayEntries = log.filter((e) => e && typeof e.ts === 'number' && e.ts >= startOfDay.getTime());
    _alertsData = todayEntries.slice(0, 8);
  } catch (_) {
    _alertsData = [];
  }
  renderCard('alerts');
}

// ── Headline ──────────────────────────────────────────────────────────────────
// "What needs you now" — one sentence rolled up from the cards already on
// screen (waiting room, demand, triage, sweep). Pure logic lives in
// today-headline.js; this is just the glue that feeds it the module's own
// in-memory state and paints the result. Re-rendered after every card fetch
// that can move the headline (wr/rm/demand/sweep) — never a fetch of its own.

function renderHeadline() {
  if (!container) return;
  const el = container.querySelector('.today-headline');
  if (!el) return;

  const oldestUnansweredMs = _rmData?.configured ? oldestUnanswered(_rmData.buckets) : null;

  const { text, severity } = buildHeadline({
    wrData: _wrData,
    rmData: _rmData,
    demandData: _demandData,
    slotsData: _slotsData,
    sweepData: _sweepData,
    oldestUnansweredMs,
    formatProvenance: window.Provenance?.formatProvenance,
  });

  el.className = `today-headline${severity ? ` today-headline--${severity}` : ' today-headline--quiet'}`;
  el.textContent = text;
}

// ── Rendering ─────────────────────────────────────────────────────────────────

function renderCard(which) {
  if (!container) return;
  const el = container.querySelector(`.today-card[data-card="${which}"]`);
  if (!el) return;

  const body = el.querySelector('.today-card-body');
  if (!body) return;

  switch (which) {
    case 'wr':
      body.innerHTML = buildWrBody();
      break;
    case 'rm':
      body.innerHTML = buildRmBody();
      break;
    case 'demand':
      body.innerHTML = buildDemandBody();
      break;
    case 'slots':
      body.innerHTML = buildSlotsBody();
      break;
    case 'sweep':
      // Decision B: removed wireSwepButtons call — delegated handler is sufficient
      body.innerHTML = buildSweepBody();
      break;
    case 'alerts':
      body.innerHTML = buildAlertsBody();
      break;
  }
}

// ── Card body builders ────────────────────────────────────────────────────────

function buildWrBody() {
  if (!_wrData) return '<span class="today-loading">Loading…</span>';
  if (_wrData.noCode) return buildNoCodeMsg();
  if (_wrData.error) return errMsg(_wrData.error);

  const { patients } = _wrData;
  if (patients.length === 0) {
    return '<span class="today-empty today-empty--green">Waiting room clear ✓</span>';
  }

  const maxWait = Math.max(...patients.map((p) => p.mins ?? 0));
  const urgency = maxWait >= 20 ? 'red' : maxWait >= 10 ? 'amber' : 'green';

  // Decision G: aria-label on hero count
  const countEl = `<span class="today-hero-count today-hero-count--${urgency}" aria-label="${patients.length} patients waiting">${patients.length}</span>`;
  const waitEl = maxWait > 0 ? `<span class="today-wait today-wait--${urgency}">Max wait ${maxWait}m</span>` : '';

  const shown = patients.slice(0, 3);
  const extra = patients.length - shown.length;
  const nameChips = shown
    .map((p) => {
      const cls = (p.mins ?? 0) >= 20 ? 'today-name-chip--red' : (p.mins ?? 0) >= 10 ? 'today-name-chip--amber' : '';
      const wait = p.mins != null ? ` · ${p.mins}m` : '';
      return `<span class="today-name-chip ${cls}">${esc(p.name)}${wait}</span>`;
    })
    .join('');
  const extraChip = extra > 0 ? `<span class="today-name-chip today-name-chip--more">+${extra} more</span>` : '';

  return `
    <div class="today-hero-row">${countEl}<span class="today-hero-label">waiting</span>${waitEl}</div>
    <div class="today-name-chips">${nameChips}${extraChip}</div>
  `;
}

function buildRmBody() {
  if (!_rmData) return '<span class="today-loading">Loading…</span>';
  if (!_rmData.configured) {
    // Quiet "optional, not set up" strip — deliberately thin and neutral so it
    // reads as a dormant feature, not a broken tile or a failure state.
    return `<div class="today-optional-strip">
      <span class="today-optional-tag">Optional</span>
      <span class="today-optional-strip-text">Triage monitor not set up</span>
      <a class="today-setup-link" href="#" data-action="open-setup">Set up →</a>
    </div>`;
  }
  if (_rmData.error && !Object.keys(_rmData.buckets).length) {
    return errMsg(_rmData.error);
  }

  const buckets = window.RequestMonitor?.BUCKETS || [];
  const pills = buckets
    .map((b) => {
      const count = _rmData.buckets?.[b.key]?.count ?? 0;
      const isReply = b.status === 'reply-received';
      // Decision E: zero-state pill logic — count === 0 is always zero, else reply or new
      const cls = count === 0 ? 'today-rm-pill--zero' : isReply ? 'today-rm-pill--reply' : 'today-rm-pill--new';
      // Decision D: show b.label instead of b.short; aria-label with full context
      return `<span class="today-rm-pill ${cls}" title="${esc(b.label)}" aria-label="${esc(b.label)}: ${count}">
        <span class="today-rm-pill-label">${esc(b.label)}</span>
        <span class="today-rm-pill-count">${count}</span>
      </span>`;
    })
    .join('');

  const errLine = _rmData.error ? errMsgInline(_rmData.error) : '';

  const oldest = oldestUnanswered(_rmData.buckets);
  const oldestLine =
    oldest != null
      ? `<div class="today-rm-oldest">Oldest unanswered request <strong>${esc(fmtAge(oldest))}</strong></div>`
      : '';

  return `<div class="today-rm-pills">${pills}</div>${oldestLine}${errLine}`;
}

function buildDemandBody() {
  if (!_demandData) return '<span class="today-loading">Loading…</span>';
  if (_demandData.noCode) return buildNoCodeMsg();

  const { medical, admin, thresholds, error, dataWarn, baseline } = _demandData;

  if (error && medical == null && admin == null) {
    return errMsg(error);
  }

  function level(key, val) {
    if (val == null) return null;
    const t = { ...DEFAULT_SUB_THRESHOLDS[key], ...(thresholds[key] || {}) };
    if (!t.enabled) return null;
    if (val >= (t.red || Infinity)) return 'red';
    if (val >= (t.amber || Infinity)) return 'amber';
    return null;
  }

  const medLevel = level('medical', medical);
  const admLevel = level('admin', admin);

  const medCls = medLevel ? `today-demand-count--${medLevel}` : '';
  const admCls = admLevel ? `today-demand-count--${admLevel}` : '';

  const medVal = medical != null ? medical : '—';
  const admVal = admin != null ? admin : '—';

  // Decision J: threshold chip when level fires
  const medFlag = medLevel
    ? `<span class="today-demand-flag today-demand-flag--${medLevel}">over threshold</span>`
    : '';
  const admFlag = admLevel
    ? `<span class="today-demand-flag today-demand-flag--${admLevel}">over threshold</span>`
    : '';

  const errLine = error ? errMsgInline(error) : '';
  const warnLine = dataWarn ? `<div class="today-demand-datawarn">⚠ ${dataWarn}</div>` : '';

  // Headroom meter — the card's altitude over the strip: the strip shows the
  // raw count, the meter shows where it sits against the amber/red thresholds.
  // Only rendered when alerting is enabled for that stream (otherwise the
  // thresholds are meaningless defaults).
  function meter(key, val) {
    if (val == null) return '';
    const t = { ...DEFAULT_SUB_THRESHOLDS[key], ...(thresholds[key] || {}) };
    if (!t.enabled || !t.red || t.red <= 0) return '';
    const pct = Math.min(100, Math.round((val / t.red) * 100));
    const amberPct = Math.max(0, Math.min(100, Math.round(((t.amber || 0) / t.red) * 100)));
    const lvl = val >= t.red ? 'red' : t.amber && val >= t.amber ? 'amber' : 'ok';
    const amberCap = t.amber && t.amber > 0 ? `<span>busy at ${t.amber}</span>` : '<span></span>';
    return `<div class="today-demand-meter" role="img" aria-label="${val} of ${t.red} red threshold">
      <div class="today-demand-meter-fill today-demand-meter-fill--${lvl}" style="width:${pct}%"></div>
      <span class="today-demand-meter-tick" style="left:${amberPct}%"></span>
    </div>
    <div class="today-demand-meter-cap">${amberCap}<span>limit ${t.red}</span></div>`;
  }

  // Decision J: count leads, label after, chip at end
  return `
    <div class="today-demand-row">
      <span class="today-demand-count ${medCls}">${medVal}</span>
      <span class="today-demand-label">medical</span>
      ${medFlag}
    </div>
    ${meter('medical', medical)}
    <div class="today-demand-row">
      <span class="today-demand-count ${admCls}">${admVal}</span>
      <span class="today-demand-label">admin</span>
      ${admFlag}
    </div>
    ${meter('admin', admin)}
    ${
      baseline
        ? `<div class="today-baseline today-baseline--${baseline.band}" title="Combined medical + admin received today vs the same weekday's history (watched days only, compared to the same hour)">${esc(baselineLine(baseline))}</div>`
        : ''
    }
    ${warnLine}
    ${errLine}
  `;
}

function buildSlotsBody() {
  if (!_slotsData) return '<span class="today-loading">Loading…</span>';
  if (_slotsData.noCode) return buildNoCodeMsg();
  if (_slotsData.error && _slotsData.count == null) {
    return errMsg(_slotsData.error);
  }

  const count = _slotsData.count ?? '—';
  const errLine = _slotsData.error ? errMsgInline(_slotsData.error) : '';

  // Item 9: surface a breach of the Slots module's own alert rules here too —
  // same threshold data, same amber/red convention as the Slots tab's ribbon
  // and pills, so a clinician sees it before ever opening that tab.
  const breaches = _slotsData.breaches || [];
  const topLevel = breaches.some((b) => b.level === 'red') ? 'red' : breaches.length ? 'amber' : null;
  const countCls = topLevel ? ` today-hero-count--${topLevel}` : '';
  const breachLines = breaches.length
    ? `<div class="today-slots-breaches">
        ${breaches
          .map(
            (b) =>
              `<span class="today-slots-breach today-slots-breach--${b.level}">${esc(b.typeName)}: ${b.count}</span>`
          )
          .join('')}
      </div>`
    : '';

  return `
    <div class="today-hero-row">
      <span class="today-hero-count${countCls}">${count}</span>
      <span class="today-hero-label">open today</span>
    </div>
    ${breachLines}
    ${errLine}
  `;
}

// Derive the single provenance summary from sweep.lastRun, or null when no
// sweep has run this session. Shared by the Sweep card and the Recent Alerts
// empty state so "ran, all clear" can never be confused with "never ran".
function sweepProvenance() {
  const lastRun = _sweepData?.lastRun;
  if (!lastRun) return null;
  const runAtDate = new Date(lastRun.runAt);
  const timeStr = runAtDate.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  const results = Array.isArray(lastRun.results) ? lastRun.results : [];
  const actionNeeded = results.filter(
    (r) => Array.isArray(r.chips) && r.chips.some((c) => isActionNeeded(c.status))
  ).length;
  // Patients actually checked this run (fall back to total when offset absent).
  const checked = typeof lastRun.processedCount === 'number' ? lastRun.processedCount : (lastRun.totalCount ?? 0);
  return { timeStr, actionNeeded, checked, lastRun };
}

function buildSweepBody() {
  if (!_sweepData) return '<span class="today-loading">Loading…</span>';

  const prov = sweepProvenance();

  // Not-run state — deliberately neutral and clearly "not done", never an
  // all-clear. The dashed strip + dimmed glyph reads as "pending", so a
  // clinician cannot mistake it for a sweep that ran and found nothing.
  if (!prov) {
    return `
      <div class="today-sweep-pending">
        <span class="today-sweep-pending-dot" aria-hidden="true"></span>
        <span class="today-sweep-pending-text">Not run yet today</span>
      </div>
      <div class="today-sweep-actions">
        <button class="today-ghost-btn" data-action="open-sweep">Run the pre-clinic sweep →</button>
      </div>
    `;
  }

  const { timeStr, actionNeeded, checked } = prov;
  const plural = checked === 1 ? 'patient' : 'patients';
  const alertWord = actionNeeded === 1 ? 'alert' : 'alerts';
  // Single clear provenance line: when, how many checked, how many alerts.
  const tone = actionNeeded > 0 ? 'today-sweep-result--action' : 'today-sweep-result--clear';

  // Plain-English headline (GP panel feedback): a bare "N alerts" count reads
  // as a stat to skim past, not a thing to act on. Say it as a sentence so the
  // action-needed fact carries its own weight. The 0 case stays neutral — it
  // must never imply "all clear" beyond what was actually checked.
  const actionVerb = actionNeeded === 1 ? 'has' : 'have';
  const headlineText =
    actionNeeded > 0
      ? `${actionNeeded} of ${checked} booked ${plural} ${actionVerb} checks due — open the sweep for names`
      : `No action-needed alerts among ${checked} checked`;

  return `
    <div class="today-sweep-summary">
      <span class="today-sweep-time">Last sweep ${esc(timeStr)}</span>
      <span class="today-sweep-headline ${tone}">${esc(headlineText)}</span>
      <span class="today-sweep-result ${tone}">${checked} ${plural} checked · ${actionNeeded} ${alertWord}</span>
    </div>
    <div class="today-sweep-actions">
      <button class="today-ghost-btn" data-action="open-sweep">Open Sweep →</button>
    </div>
  `;
}

function buildNoCodeMsg() {
  return `
    <span class="today-muted">No practice code — open a Medicus tab or set it up.</span>
    <a class="today-setup-link" href="#" data-action="open-setup">Set up now →</a>
  `;
}

function buildAlertsBody() {
  if (!_alertsData) return '<span class="today-loading">Loading…</span>';
  if (_alertsData.length === 0) {
    // Back the "no alerts" claim with sweep provenance so a clinician can tell
    // "ran, all clear" from "nothing has checked yet".
    const prov = sweepProvenance();
    if (prov && prov.actionNeeded === 0) {
      const plural = prov.checked === 1 ? 'patient' : 'patients';
      return `<span class="today-empty today-empty--green">No alerts — sweep ${esc(prov.timeStr)} checked ${prov.checked} ${plural}, all clear ✓</span>`;
    }
    if (!prov) {
      return '<span class="today-empty">No alerts logged · no sweep run yet today</span>';
    }
    return '<span class="today-empty today-empty--green">No alerts logged today</span>';
  }

  // Decision C: sub-rag returns '' so label doubling is avoided;
  // rm → 'Triage', triage → 'Triage alert' unchanged.
  function channelLabel(channel) {
    if (channel === 'rm') return 'Triage';
    if (channel === 'triage') return 'Triage alert';
    if (channel === 'sub-rag') return '';
    return channel;
  }

  function fmtTime(ts) {
    const d = new Date(ts);
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  }

  const rows = _alertsData
    .map((e) => {
      const dotCls =
        e.level === 'red'
          ? 'today-alert-dot--red'
          : e.level === 'amber'
            ? 'today-alert-dot--amber'
            : 'today-alert-dot--green';
      // Decision C: omit separator when prefix is empty
      const prefix = channelLabel(e.channel);
      const labelText = prefix ? `${prefix}: ${esc(e.label)}` : esc(e.label);
      // Decision K: aria-label on dot
      return `
      <div class="today-alert-row">
        <span class="today-alert-time">${fmtTime(e.ts)}</span>
        <span class="today-alert-dot ${dotCls}" role="img" aria-label="${esc(e.level)}"></span>
        <span class="today-alert-label">${labelText}</span>
      </div>`;
    })
    .join('');

  return `<div class="today-alert-list">${rows}</div>`;
}

// ── Wire event handlers ────────────────────────────────────────────────────────

// Decision B: wireSweepButtons and wireSwepButtons alias removed entirely.
// The delegated handler in wireCardInteractions handles open-sweep.

// Named so cleanup() can remove it — the shell reuses the container across
// modules, so an anonymous delegate stacked one copy per visit (audit H8-class).
let _cardActionHandler = null;

function wireCardInteractions() {
  if (!container) return;

  // Delegated handler — works even after card bodies are re-rendered
  _cardActionHandler = (e) => {
    const actionEl = e.target.closest('[data-action]');
    if (!actionEl) return;
    const action = actionEl.dataset.action;
    e.preventDefault();

    if (action === 'open-setup') openSetup();
    if (action === 'open-sweep') navTo('sweep');
  };
  container.addEventListener('click', _cardActionHandler);

  // Decision A: use btn.dataset.nav (not btn.closest('.today-card')?.dataset.card)
  // Decision H: replace title with aria-label on .today-card-open
  container.querySelectorAll('.today-card-open').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const mod = btn.dataset.nav;
      if (mod) navTo(mod);
    });
  });

  container.querySelector('#todayFollowups')?.addEventListener('click', () => navTo('followups'));
}

// ── Follow-ups line ───────────────────────────────────────────────────────────
// One compact line under the headline: the personal safety-net ledger's due
// state. Hidden entirely when the ledger has no open entries (no noise for
// non-users); red when anything has lapsed, amber when something is due
// today. Reads storage directly — the ledger is machine-local by design.

function renderFollowupsLine() {
  const el = container?.querySelector('#todayFollowups');
  if (!el) return;
  chrome.storage.local.get(['followups.entries'], (res) => {
    if (!container) return;
    const c = followupCounts(res['followups.entries'], Date.now());
    if (!c.open) {
      el.classList.add('hidden');
      return;
    }
    const bits = [];
    if (c.lapsed) bits.push(`<strong>${c.lapsed} overdue</strong>`);
    if (c.dueToday) bits.push(`${c.dueToday} due today`);
    const rest = c.open - c.lapsed - c.dueToday;
    if (rest) bits.push(`${rest} waiting`);
    el.classList.remove('hidden');
    el.classList.toggle('today-followups--red', c.lapsed > 0);
    el.classList.toggle('today-followups--amber', c.lapsed === 0 && c.dueToday > 0);
    el.innerHTML = `Follow-ups: ${bits.join(' &middot; ')} &rarr;`;
  });
}

// ── Full render (scaffold) ────────────────────────────────────────────────────

function renderScaffold() {
  if (!container) return;

  const cards = [
    {
      id: 'wr',
      label: 'Waiting Room',
      navModule: 'sentinel',
    },
    {
      id: 'rm',
      label: 'Triage Load',
      navModule: 'reception',
      // Glossary tooltip (U1): explain what "Triage Load" means + that it needs setup.
      tipKey: 'triage-load',
      tipText: 'How many triage requests are waiting. Needs the Triage Monitor set up in Options.',
    },
    {
      id: 'demand',
      label: 'Demand Today',
      navModule: 'submissions',
    },
    {
      id: 'slots',
      label: 'Slots Remaining',
      navModule: 'slots',
    },
    {
      id: 'sweep',
      label: 'Morning Sweep',
      navModule: 'sweep',
    },
    {
      id: 'alerts',
      label: 'Recent Alerts',
      navModule: null,
    },
  ];

  container.innerHTML = `
    <div class="module-wrap today-module">
      <div class="today-headline today-headline--quiet" aria-live="polite">Working out what needs you…</div>
      <button class="today-followups hidden" id="todayFollowups" data-nav="followups" aria-label="Open Follow-ups"></button>
      <div class="today-cards">
        ${cards
          .map(
            (c) => `
          <div class="today-card" data-card="${c.id}">
            <div class="today-card-header">
              <span class="today-card-label"${c.tipKey ? ` data-tip-key="${esc(c.tipKey)}" title="${esc(c.tipText || '')}" tabindex="0" role="button"` : ''}>${esc(c.label)}</span>
              ${c.navModule ? `<button class="today-card-open" data-nav="${c.navModule}" aria-label="Open ${esc(c.label)}">→</button>` : ''}
            </div>
            <div class="today-card-body" aria-live="polite"><span class="today-loading">Loading…</span></div>
          </div>
        `
          )
          .join('')}
      </div>
    </div>
  `;

  wireCardInteractions();
}

// ── Pollers ───────────────────────────────────────────────────────────────────

function addTimer(fn, ms) {
  const id = setInterval(() => {
    if (document.visibilityState === 'visible') fn();
  }, ms);
  _timers.push(id);
  return id;
}

// ── Storage listener ──────────────────────────────────────────────────────────

function onStorageChange(changes) {
  if (!container) return;
  if (changes['submissions.thresholds']) fetchDemand();
  if (changes['sweep.lastRun']) fetchSweep();
  if (changes['suite.alertLog']) fetchAlerts();
  if (changes['followups.entries']) renderFollowupsLine();
  // Item 9: a rule edited in the Slots tab or options.html#sect-slots should
  // reflect on the Slots Today card / headline without waiting for the next poll.
  if (changes['slots.alertRules']) fetchSlots();
}

// ── Init / Cleanup ────────────────────────────────────────────────────────────

export async function init(el) {
  container = el;
  _wrData = null;
  _rmData = null;
  _demandData = null;
  _slotsData = null;
  _sweepData = null;
  _alertsData = null;
  _timers = [];

  renderScaffold();

  // Initial fetches — all in parallel
  fetchWr();
  fetchRm();
  fetchDemand();
  fetchSlots();
  fetchSweep();
  fetchAlerts();
  renderFollowupsLine();

  // Pollers
  addTimer(fetchWr, WR_POLL_MS);
  addTimer(fetchRm, DEMAND_POLL_MS);
  addTimer(fetchDemand, DEMAND_POLL_MS);
  addTimer(fetchSlots, DEMAND_POLL_MS);
  addTimer(fetchAlerts, 30 * 1000);
  // Sweep is not polled on interval — re-reads on storage change only

  // Storage watcher
  chrome.storage.onChanged.addListener(onStorageChange);

  // Refresh on visibility restore
  const onVisible = () => {
    if (document.visibilityState === 'visible') {
      fetchWr();
      fetchRm();
      fetchDemand();
      fetchSlots();
      fetchSweep();
      fetchAlerts();
      renderFollowupsLine();
    }
  };
  document.addEventListener('visibilitychange', onVisible);

  return function cleanup() {
    _timers.forEach(clearInterval);
    _timers = [];
    chrome.storage.onChanged.removeListener(onStorageChange);
    document.removeEventListener('visibilitychange', onVisible);
    if (container && _cardActionHandler) container.removeEventListener('click', _cardActionHandler);
    _cardActionHandler = null;
    container = null;
  };
}
