// © 2026 Graysbrook Ltd. Proprietary — all rights reserved. See LICENSE.
'use strict';

import { windowTaskList, ledgerSeriesForDay } from '../submissions/submissions-core.js';
import { recordTaskLists } from '../submissions/submissions-ledger.js';

function todayISO() {
  // Local calendar date (NOT UTC) — toISOString() would roll to the next/previous
  // day in the early/late hours and query the wrong day's tasks.
  const d = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

// Fetches the appointment-book once and extracts both slot counts and the
// practice-wide waiting room in a single request.
async function fetchSlotsAndWaitingRoom(base, hiddenTypes = new Set()) {
  const today = todayISO();
  const now = new Date();
  const url = `${base}/scheduling/data/appointment-book/embedded-overview?date=${today}&filterByUsualLocation=false`;
  const r = await fetch(url, { credentials: 'include' });
  if (!r.ok) throw new Error(`Slots HTTP ${r.status}`);
  const raw = await r.json();

  // ── Slots ─────────────────────────────────────────────────────────────────
  const entries = [];
  const byStaff = {};
  let amRemaining = 0;
  let pmRemaining = 0;

  // ── Waiting room (practice-wide) ───────────────────────────────────────────
  const wrAppointments = [];

  (raw.staffSchedules || []).forEach((staff) => {
    const staffName = staff.name || 'Unknown';
    (staff.schedule || []).forEach((session) => {
      (session.entries || []).forEach((entry) => {
        const entryType = entry.diaryEntryType?.value;

        if (entryType === 'slot') {
          if (entry.startDateTime && new Date(entry.startDateTime) <= now) return;
          // Mirror the Slots tab: exclude appointment types the user has unticked
          // (triage / holding / etc. via slots.hiddenTypes) so the count reflects
          // the bookable slots they actually care about.
          const type = entry.appointmentType?.name || 'Unknown';
          if (hiddenTypes.has(type)) return;
          const hour = entry.startDateTime ? new Date(entry.startDateTime).getHours() : 0;
          const isAm = hour < 12;
          entries.push({ staff: staffName, type, startDateTime: entry.startDateTime || '' });
          if (!byStaff[staffName]) byStaff[staffName] = { amRemaining: 0, pmRemaining: 0 };
          if (isAm) {
            byStaff[staffName].amRemaining++;
            amRemaining++;
          } else {
            byStaff[staffName].pmRemaining++;
            pmRemaining++;
          }
          return;
        }

        if (entryType === 'appointment') {
          const status = entry.displayStatus?.value;
          // Include arrived (in waiting room) and booked (upcoming) only.
          if (status !== 'arrived' && status !== 'booked') return;
          wrAppointments.push({
            patientName: entry.patient?.name || 'Unknown',
            staffName,
            start: entry.startDateTime || '',
            reason: entry.compiledReasonForAppointment || '',
            deliveryMode: entry.deliveryMode?.value || '',
            isArrived: status === 'arrived',
          });
        }
      });
    });
  });

  const arrivedCount = wrAppointments.filter((a) => a.isArrived).length;

  return {
    slots: { entries, amRemaining, pmRemaining, totalRemaining: amRemaining + pmRemaining, byStaff },
    waitingRoom: { appointments: wrAppointments, arrivedCount },
  };
}

async function fetchSubmissions(base) {
  const today = todayISO();
  const TASK_TYPES = [
    { key: 'medical', apiType: 'medical_patient_request_task' },
    { key: 'admin', apiType: 'admin_patient_request_task' },
    { key: 'investigation', apiType: 'review_investigation_results_task' },
    { key: 'rxRoutine', apiType: 'prescription_request_task_routine' },
    { key: 'rxNonRoutine', apiType: 'prescription_request_task_non_routine' },
  ];

  const results = await Promise.allSettled(
    TASK_TYPES.map(async (tt) => {
      // The task-list endpoint filters by `createdAt_startDate` / `createdAt_endDate`.
      // Using plain `startDate` / `endDate` is silently ignored and returns the entire
      // open-task backlog — which is what inflated demand/velocity/PPI to tens of thousands.
      const url = `${base}/tasks/data/${tt.apiType}/task-list?createdAt_startDate=${today}&createdAt_endDate=${today}`;
      const r = await fetch(url, { credentials: 'include' });
      if (!r.ok) throw new Error(`${tt.key} HTTP ${r.status}`);
      const d = await r.json();
      // windowTaskList guards demand/velocity/PPI against the server ignoring the
      // createdAt_* filter (the v3.35.2 failure class, in either direction).
      const w = windowTaskList(d, today, today);
      return { key: tt.key, tasks: w.tasks, filterIgnored: w.filterIgnored };
    })
  );

  const keys = TASK_TYPES.map((tt) => tt.key);
  const byHour = Array.from({ length: 24 }, (_, i) => ({
    hour: i,
    medical: 0,
    admin: 0,
    rxRoutine: 0,
    rxNonRoutine: 0,
    investigation: 0,
  }));
  const totals = { medical: 0, admin: 0, rxRoutine: 0, rxNonRoutine: 0, investigation: 0, all: 0 };
  const tasks = [];
  let filterIgnored = false;

  results.forEach((res) => {
    if (res.status !== 'fulfilled') return;
    const { key, tasks: ts } = res.value;
    if (res.value.filterIgnored) filterIgnored = true;
    ts.forEach((t) => {
      const hourOfDay = new Date(t.createdAt).getHours();
      tasks.push({ id: t.id, type: key, createdAt: t.createdAt, hourOfDay });
    });
  });

  // Demand/velocity/PPI count from the day ledger (tasks seen today, kept
  // after completion), not the raw response: the task-list API only contains
  // OPEN tasks, so raw totals sag as the team clears work and understate true
  // demand (v3.153.0).
  let ledgerSeries = null;
  try {
    const byKey = {};
    for (const res of results) {
      if (res.status === 'fulfilled') byKey[res.value.key] = res.value.tasks;
    }
    const ledger = await recordTaskLists(byKey);
    ledgerSeries = ledgerSeriesForDay(ledger, today, keys);
  } catch (_) {
    // Storage failure — fall back to live (open-only) counts.
  }

  for (const key of keys) {
    if (ledgerSeries) {
      totals[key] = ledgerSeries[key].total;
      for (let h = 0; h < 24; h++) byHour[h][key] = ledgerSeries[key].hourly[h];
    } else {
      for (const t of tasks) {
        if (t.type !== key) continue;
        if (byHour[t.hourOfDay]) byHour[t.hourOfDay][key]++;
        totals[key]++;
      }
    }
    totals.all += totals[key];
  }

  return { tasks, totals, byHour, filterIgnored };
}

// Build the request-monitor stream from the cached poll state written by the
// service worker (shared/request-monitor.js pollAll → suite.requestMonitor.state).
// Condor must NOT fetch the task lists itself: the SW alarm is the single
// owner of that polling, and an earlier version of this function fetched a
// non-existent /admin/data/request-monitor endpoint — the resulting 404 made
// a fully-configured task inbox render as "not configured".
//
// Returns:
//   { items, urgentCount, totalCount, byAgeBucket, lastPoll }  — usable data
//   { unavailable: true, reason }                              — configured but no
//                                                                 usable state yet
export function buildRequestMonitorFromState(state) {
  if (!state || !state.lastPoll) {
    return { unavailable: true, reason: 'no poll data yet — the monitor polls in the background' };
  }
  if (state.error) {
    return { unavailable: true, reason: String(state.error) };
  }

  const now = Date.now();
  const items = [];
  for (const bucket of Object.values(state.buckets || {})) {
    for (const t of bucket?.items || []) {
      items.push({
        id: t.id,
        patient: t.patient || '',
        summary: t.summary || '',
        priority: t.priority || '',
        createdAt: t.createdAt,
        ageMs: now - new Date(t.createdAt).getTime(),
      });
    }
  }

  const urgentCount = items.filter((i) => /urgent/i.test(i.priority)).length;
  const byAgeBucket = { lt1h: 0, h1to4: 0, h4to8: 0, gt8h: 0 };
  items.forEach((i) => {
    if (i.ageMs < 3600000) byAgeBucket.lt1h++;
    else if (i.ageMs < 14400000) byAgeBucket.h1to4++;
    else if (i.ageMs < 28800000) byAgeBucket.h4to8++;
    else byAgeBucket.gt8h++;
  });

  return { items, urgentCount, totalCount: items.length, byAgeBucket, lastPoll: state.lastPoll };
}

async function fetchActivity(base) {
  const today = todayISO();
  const url = `${base}/reporting/data/activity/report?startDate=${today}&endDate=${today}`;
  const r = await fetch(url, { credentials: 'include' });
  if (!r.ok) throw new Error(`Activity HTTP ${r.status}`);
  const d = await r.json();

  const totals = { consultations: 0, routineRx: 0, nonRoutineRx: 0, reviews: 0, documents: 0, results: 0, all: 0 };
  const rows = (d.rowData || []).map((row) => {
    const consultations = row.consultations || 0;
    const routineRx = row.routinePrescriptionRequestTasks || 0;
    const nonRoutineRx = row.nonRoutinePrescriptionRequestTasks || 0;
    const reviews = row.medicationReviews || 0;
    const documents = row.documentTasks || 0;
    const results = row.investigationReportTasks || 0;
    const total = consultations + routineRx + nonRoutineRx + reviews + documents + results;
    totals.consultations += consultations;
    totals.routineRx += routineRx;
    totals.nonRoutineRx += nonRoutineRx;
    totals.reviews += reviews;
    totals.documents += documents;
    totals.results += results;
    totals.all += total;
    return { name: row.name || 'Unknown', consultations, routineRx, nonRoutineRx, reviews, documents, results, total };
  });

  return { rows, totals };
}

function computeCapacityPreset(storage, slotsData) {
  const presets = storage['capacity.presets'];
  const activeId = storage['capacity.activePresetId'];
  if (!presets || !activeId) return null;

  const preset = (Array.isArray(presets) ? presets : Object.values(presets)).find((p) => p.id === activeId);
  if (!preset?.minimumByDay) return null;

  const dayKey = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'][new Date().getDay()];
  const minimum = preset.minimumByDay[dayKey] ?? 0;
  const remaining = slotsData?.totalRemaining ?? 0;

  let status;
  if (remaining === 0) status = 'closed';
  else if (minimum === 0) status = 'sufficient';
  else if (remaining / minimum < 0.5) status = 'low';
  else if (remaining / minimum < 0.75) status = 'tight';
  else status = 'sufficient';

  return { minimum, status };
}

export async function fetchAllStreams() {
  const storageKeys = [
    'suite.practiceCode',
    'capacity.presets',
    'capacity.activePresetId',
    'suite.requestMonitor.enabled',
    'suite.requestMonitor.assigneeId',
    'suite.requestMonitor.state',
    'slots.hiddenTypes',
  ];

  const storage = await chrome.storage.local.get(storageKeys);
  const siteId = storage['suite.practiceCode'] || null;
  const hiddenTypes = new Set(storage['slots.hiddenTypes'] || []);
  const fetchErrors = [];

  if (!siteId) {
    return {
      siteId: null,
      slots: null,
      waitingRoom: null,
      submissions: null,
      requestMonitor: null,
      activity: null,
      capacityPreset: null,
      fetchErrors: ['No practice code configured'],
    };
  }

  const base = `https://${siteId}.api.england.medicus.health`;
  const rmConfig = {
    enabled: storage['suite.requestMonitor.enabled'],
    assigneeId: storage['suite.requestMonitor.assigneeId'],
  };
  const rmEnabled = rmConfig.enabled && rmConfig.assigneeId;

  const [slotsAndWrRes, subRes, actRes] = await Promise.allSettled([
    fetchSlotsAndWaitingRoom(base, hiddenTypes),
    fetchSubmissions(base),
    fetchActivity(base),
  ]);

  const slots = slotsAndWrRes.status === 'fulfilled' ? slotsAndWrRes.value.slots : null;
  const waitingRoom = slotsAndWrRes.status === 'fulfilled' ? slotsAndWrRes.value.waitingRoom : null;
  if (slotsAndWrRes.status === 'rejected')
    fetchErrors.push(`slots: ${slotsAndWrRes.reason?.message || slotsAndWrRes.reason}`);

  const submissions = subRes.status === 'fulfilled' ? subRes.value : null;
  if (subRes.status === 'rejected') fetchErrors.push(`submissions: ${subRes.reason?.message || subRes.reason}`);

  // null = Request Monitor not configured (cards show "enable in Settings");
  // { unavailable, reason } = configured but state missing/errored (fail-visible,
  // must NOT render as "not configured").
  let requestMonitor = null;
  if (rmEnabled) {
    requestMonitor = buildRequestMonitorFromState(storage['suite.requestMonitor.state']);
    if (requestMonitor.unavailable) {
      fetchErrors.push(`requestMonitor: ${requestMonitor.reason}`);
    }
  }

  const activity = actRes.status === 'fulfilled' ? actRes.value : null;
  if (actRes.status === 'rejected') fetchErrors.push(`activity: ${actRes.reason?.message || actRes.reason}`);

  const capacityPreset = computeCapacityPreset(storage, slots);

  return {
    siteId,
    slots,
    waitingRoom,
    submissions,
    requestMonitor,
    activity,
    capacityPreset,
    fetchErrors,
  };
}
